﻿
namespace MyProjectDTI02
{
    partial class FrmLogin
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new System.Windows.Forms.Label();
            pictureBox1 = new System.Windows.Forms.PictureBox();
            label2 = new System.Windows.Forms.Label();
            label3 = new System.Windows.Forms.Label();
            tbUsername = new System.Windows.Forms.TextBox();
            tbPassword = new System.Windows.Forms.TextBox();
            rdoStudent = new System.Windows.Forms.RadioButton();
            rdoTeacher = new System.Windows.Forms.RadioButton();
            btLogin = new System.Windows.Forms.Button();
            btExit = new System.Windows.Forms.Button();
            btnLogout = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.BackColor = System.Drawing.Color.Yellow;
            label1.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label1.ForeColor = System.Drawing.Color.Blue;
            label1.Location = new System.Drawing.Point(61, 73);
            label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(814, 100);
            label1.TabIndex = 0;
            label1.Text = "DTI Soft V.1.0";
            label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = System.Drawing.SystemColors.ButtonFace;
            pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            pictureBox1.ErrorImage = null;
            pictureBox1.Image = Properties.Resources.login;
            pictureBox1.Location = new System.Drawing.Point(131, 202);
            pictureBox1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new System.Drawing.Size(200, 292);
            pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            pictureBox1.TabIndex = 1;
            pictureBox1.TabStop = false;
            // 
            // label2
            // 
            label2.Location = new System.Drawing.Point(371, 227);
            label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(129, 65);
            label2.TabIndex = 2;
            label2.Text = "ชื่อผู้ใช้";
            label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label3
            // 
            label3.Location = new System.Drawing.Point(371, 292);
            label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            label3.Name = "label3";
            label3.Size = new System.Drawing.Size(129, 65);
            label3.TabIndex = 3;
            label3.Text = "รหัสผ่าน";
            label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tbUsername
            // 
            tbUsername.Location = new System.Drawing.Point(509, 242);
            tbUsername.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            tbUsername.Name = "tbUsername";
            tbUsername.PlaceholderText = "ภาษาอังกฤษเท่านั้น";
            tbUsername.Size = new System.Drawing.Size(327, 31);
            tbUsername.TabIndex = 4;
            tbUsername.KeyPress += tbUsername_KeyPress;
            // 
            // tbPassword
            // 
            tbPassword.Location = new System.Drawing.Point(509, 307);
            tbPassword.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            tbPassword.Name = "tbPassword";
            tbPassword.PasswordChar = '*';
            tbPassword.PlaceholderText = "เป็นตัวเลขเท่านั้น ไม่ต่ำกว่า 6 ตัว";
            tbPassword.Size = new System.Drawing.Size(327, 31);
            tbPassword.TabIndex = 5;
            tbPassword.KeyPress += tbPassword_KeyPress;
            // 
            // rdoStudent
            // 
            rdoStudent.AutoSize = true;
            rdoStudent.Checked = true;
            rdoStudent.Location = new System.Drawing.Point(539, 392);
            rdoStudent.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            rdoStudent.Name = "rdoStudent";
            rdoStudent.Size = new System.Drawing.Size(98, 29);
            rdoStudent.TabIndex = 6;
            rdoStudent.TabStop = true;
            rdoStudent.Text = "Student";
            rdoStudent.UseVisualStyleBackColor = true;
            // 
            // rdoTeacher
            // 
            rdoTeacher.AutoSize = true;
            rdoTeacher.Location = new System.Drawing.Point(681, 392);
            rdoTeacher.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            rdoTeacher.Name = "rdoTeacher";
            rdoTeacher.Size = new System.Drawing.Size(95, 29);
            rdoTeacher.TabIndex = 7;
            rdoTeacher.Text = "Teacher";
            rdoTeacher.UseVisualStyleBackColor = true;
            // 
            // btLogin
            // 
            btLogin.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            btLogin.Image = Properties.Resources.start;
            btLogin.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            btLogin.Location = new System.Drawing.Point(437, 448);
            btLogin.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            btLogin.Name = "btLogin";
            btLogin.Size = new System.Drawing.Size(217, 72);
            btLogin.TabIndex = 8;
            btLogin.Text = "เข้าใช้งานระบบ";
            btLogin.UseVisualStyleBackColor = true;
            btLogin.Click += btLogin_Click;
            // 
            // btExit
            // 
            btExit.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            btExit.Image = Properties.Resources.cancel;
            btExit.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            btExit.Location = new System.Drawing.Point(681, 448);
            btExit.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            btExit.Name = "btExit";
            btExit.Size = new System.Drawing.Size(194, 72);
            btExit.TabIndex = 9;
            btExit.Text = "ยกเลิก";
            btExit.UseVisualStyleBackColor = true;
            btExit.Click += btExit_Click;
            // 
            // btnLogout
            // 
            btnLogout.Image = Properties.Resources.exit3;
            btnLogout.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            btnLogout.Location = new System.Drawing.Point(437, 545);
            btnLogout.Name = "btnLogout";
            btnLogout.Size = new System.Drawing.Size(438, 64);
            btnLogout.TabIndex = 10;
            btnLogout.Text = "ออกจากระบบ";
            btnLogout.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            btnLogout.UseVisualStyleBackColor = true;
            btnLogout.Click += btnLogout_Click;
            // 
            // FrmLogin
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            ClientSize = new System.Drawing.Size(931, 632);
            Controls.Add(btnLogout);
            Controls.Add(btExit);
            Controls.Add(btLogin);
            Controls.Add(rdoTeacher);
            Controls.Add(rdoStudent);
            Controls.Add(tbPassword);
            Controls.Add(tbUsername);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(pictureBox1);
            Controls.Add(label1);
            Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            MinimizeBox = false;
            Name = "FrmLogin";
            StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            Text = "Login-DTI Soft V.1.0";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tbUsername;
        private System.Windows.Forms.TextBox tbPassword;
        private System.Windows.Forms.RadioButton rdoStudent;
        private System.Windows.Forms.RadioButton rdoTeacher;
        private System.Windows.Forms.Button btLogin;
        private System.Windows.Forms.Button btExit;
        private System.Windows.Forms.Button btnLogout;
    }
}

