﻿
namespace MyProjectDTI02
{
    partial class FrmWelcome
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            label1 = new System.Windows.Forms.Label();
            tbName = new System.Windows.Forms.TextBox();
            label2 = new System.Windows.Forms.Label();
            label3 = new System.Windows.Forms.Label();
            dtpBirthDate = new System.Windows.Forms.DateTimePicker();
            rdoFemale = new System.Windows.Forms.RadioButton();
            rdoMale = new System.Windows.Forms.RadioButton();
            btMainMenu = new System.Windows.Forms.Button();
            btOk = new System.Windows.Forms.Button();
            btCancel = new System.Windows.Forms.Button();
            lblShowResult = new System.Windows.Forms.Label();
            toolStrip1 = new System.Windows.Forms.ToolStrip();
            lblNameShow = new System.Windows.Forms.ToolStripLabel();
            lblDatetimeShow = new System.Windows.Forms.ToolStripLabel();
            timer1 = new System.Windows.Forms.Timer(components);
            toolStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.BackColor = System.Drawing.Color.Yellow;
            label1.Font = new System.Drawing.Font("Segoe UI", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label1.ForeColor = System.Drawing.Color.Blue;
            label1.Location = new System.Drawing.Point(204, 63);
            label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(570, 100);
            label1.TabIndex = 3;
            label1.Text = "Welcome";
            label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            label1.UseCompatibleTextRendering = true;
            label1.Click += label1_Click;
            // 
            // tbName
            // 
            tbName.Location = new System.Drawing.Point(379, 228);
            tbName.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            tbName.Name = "tbName";
            tbName.PlaceholderText = "ภาษาอังกฤษเท่านั้น";
            tbName.Size = new System.Drawing.Size(327, 31);
            tbName.TabIndex = 6;
            tbName.TextChanged += tbUsername_TextChanged;
            tbName.KeyPress += tbName_KeyPress;
            // 
            // label2
            // 
            label2.Location = new System.Drawing.Point(241, 213);
            label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(129, 65);
            label2.TabIndex = 5;
            label2.Text = "ชื่อ-นามสกุล";
            label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            label2.Click += label2_Click;
            // 
            // label3
            // 
            label3.Location = new System.Drawing.Point(241, 300);
            label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            label3.Name = "label3";
            label3.Size = new System.Drawing.Size(129, 65);
            label3.TabIndex = 7;
            label3.Text = "วัน-เดือน-ปี";
            label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // dtpBirthDate
            // 
            dtpBirthDate.Location = new System.Drawing.Point(379, 310);
            dtpBirthDate.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            dtpBirthDate.Name = "dtpBirthDate";
            dtpBirthDate.Size = new System.Drawing.Size(327, 31);
            dtpBirthDate.TabIndex = 8;
            dtpBirthDate.Value = new System.DateTime(2024, 6, 16, 15, 12, 19, 0);
            // 
            // rdoFemale
            // 
            rdoFemale.AutoSize = true;
            rdoFemale.Location = new System.Drawing.Point(526, 387);
            rdoFemale.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            rdoFemale.Name = "rdoFemale";
            rdoFemale.Size = new System.Drawing.Size(70, 29);
            rdoFemale.TabIndex = 10;
            rdoFemale.Text = "หญิง";
            rdoFemale.UseVisualStyleBackColor = true;
            // 
            // rdoMale
            // 
            rdoMale.AutoSize = true;
            rdoMale.Checked = true;
            rdoMale.Location = new System.Drawing.Point(383, 387);
            rdoMale.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            rdoMale.Name = "rdoMale";
            rdoMale.Size = new System.Drawing.Size(65, 29);
            rdoMale.TabIndex = 9;
            rdoMale.TabStop = true;
            rdoMale.Text = "ชาย";
            rdoMale.UseVisualStyleBackColor = true;
            // 
            // btMainMenu
            // 
            btMainMenu.Image = Properties.Resources.pevious1;
            btMainMenu.Location = new System.Drawing.Point(809, 145);
            btMainMenu.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            btMainMenu.Name = "btMainMenu";
            btMainMenu.Size = new System.Drawing.Size(146, 85);
            btMainMenu.TabIndex = 11;
            btMainMenu.Text = "หน้าจอหลัก";
            btMainMenu.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            btMainMenu.UseVisualStyleBackColor = true;
            btMainMenu.Click += btMainMenu_Click;
            // 
            // btOk
            // 
            btOk.Image = Properties.Resources.ok;
            btOk.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            btOk.Location = new System.Drawing.Point(809, 262);
            btOk.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            btOk.Name = "btOk";
            btOk.Size = new System.Drawing.Size(146, 85);
            btOk.TabIndex = 12;
            btOk.Text = "ตกลง";
            btOk.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            btOk.UseVisualStyleBackColor = true;
            btOk.Click += btOk_Click;
            // 
            // btCancel
            // 
            btCancel.Image = Properties.Resources.cancel;
            btCancel.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            btCancel.Location = new System.Drawing.Point(809, 377);
            btCancel.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            btCancel.Name = "btCancel";
            btCancel.Size = new System.Drawing.Size(146, 85);
            btCancel.TabIndex = 13;
            btCancel.Text = "ยกเลิก";
            btCancel.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            btCancel.UseVisualStyleBackColor = true;
            btCancel.Click += btCancel_Click;
            // 
            // lblShowResult
            // 
            lblShowResult.BackColor = System.Drawing.Color.Yellow;
            lblShowResult.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            lblShowResult.ForeColor = System.Drawing.Color.Blue;
            lblShowResult.Location = new System.Drawing.Point(204, 442);
            lblShowResult.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            lblShowResult.Name = "lblShowResult";
            lblShowResult.Size = new System.Drawing.Size(570, 293);
            lblShowResult.TabIndex = 14;
            lblShowResult.Text = "??????";
            lblShowResult.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            lblShowResult.UseCompatibleTextRendering = true;
            // 
            // toolStrip1
            // 
            toolStrip1.Dock = System.Windows.Forms.DockStyle.Bottom;
            toolStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] { lblNameShow, lblDatetimeShow });
            toolStrip1.Location = new System.Drawing.Point(0, 710);
            toolStrip1.Name = "toolStrip1";
            toolStrip1.Padding = new System.Windows.Forms.Padding(0, 0, 3, 0);
            toolStrip1.Size = new System.Drawing.Size(1004, 30);
            toolStrip1.TabIndex = 15;
            toolStrip1.Text = "toolStrip1";
            // 
            // lblNameShow
            // 
            lblNameShow.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            lblNameShow.ForeColor = System.Drawing.Color.Blue;
            lblNameShow.Name = "lblNameShow";
            lblNameShow.Size = new System.Drawing.Size(70, 25);
            lblNameShow.Text = "Name?";
            // 
            // lblDatetimeShow
            // 
            lblDatetimeShow.Name = "lblDatetimeShow";
            lblDatetimeShow.Size = new System.Drawing.Size(90, 25);
            lblDatetimeShow.Text = "datetime?";
            // 
            // timer1
            // 
            timer1.Tick += timer1_Tick;
            // 
            // FrmWelcome
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            ClientSize = new System.Drawing.Size(1004, 740);
            Controls.Add(toolStrip1);
            Controls.Add(lblShowResult);
            Controls.Add(btCancel);
            Controls.Add(btOk);
            Controls.Add(btMainMenu);
            Controls.Add(rdoFemale);
            Controls.Add(rdoMale);
            Controls.Add(dtpBirthDate);
            Controls.Add(label3);
            Controls.Add(tbName);
            Controls.Add(label2);
            Controls.Add(label1);
            Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            Name = "FrmWelcome";
            Text = "FrmWelcome";
            toolStrip1.ResumeLayout(false);
            toolStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DateTimePicker dtpBirthDate;
        private System.Windows.Forms.RadioButton rdoFemale;
        private System.Windows.Forms.RadioButton rdoMale;
        private System.Windows.Forms.Button btMainMenu;
        private System.Windows.Forms.Button btOk;
        private System.Windows.Forms.Button btCancel;
        private System.Windows.Forms.Label lblShowResult;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripLabel lblNameShow;
        private System.Windows.Forms.ToolStripLabel lblDatetimeShow;
        private System.Windows.Forms.Timer timer1;
    }
}