﻿
namespace MyProjectDTI02
{
    partial class FrmShape
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            btnMainMenu = new System.Windows.Forms.Button();
            label1 = new System.Windows.Forms.Label();
            kk = new System.Windows.Forms.ToolStrip();
            lblNameShow = new System.Windows.Forms.ToolStripLabel();
            lblDatetimeShow = new System.Windows.Forms.ToolStripLabel();
            tabControl1 = new System.Windows.Forms.TabControl();
            tabPage1 = new System.Windows.Forms.TabPage();
            lblCircleResult = new System.Windows.Forms.Label();
            btnCircleCancel = new System.Windows.Forms.Button();
            btnCircleCalculate = new System.Windows.Forms.Button();
            label4 = new System.Windows.Forms.Label();
            rdoCircleRound = new System.Windows.Forms.RadioButton();
            rdoCircleArea = new System.Windows.Forms.RadioButton();
            tbCircleRadius = new System.Windows.Forms.TextBox();
            label6 = new System.Windows.Forms.Label();
            tabPage2 = new System.Windows.Forms.TabPage();
            tbSquareHeight = new System.Windows.Forms.TextBox();
            label13 = new System.Windows.Forms.Label();
            lblSquareResult = new System.Windows.Forms.Label();
            btnSquareCancel = new System.Windows.Forms.Button();
            btnSquareCalculate = new System.Windows.Forms.Button();
            label8 = new System.Windows.Forms.Label();
            rdoSquareRound = new System.Windows.Forms.RadioButton();
            rdoSquareArea = new System.Windows.Forms.RadioButton();
            tbSquareWidth = new System.Windows.Forms.TextBox();
            label9 = new System.Windows.Forms.Label();
            tabPage3 = new System.Windows.Forms.TabPage();
            tbTriangleCorner = new System.Windows.Forms.TextBox();
            label15 = new System.Windows.Forms.Label();
            tbTriangleHeight = new System.Windows.Forms.TextBox();
            label12 = new System.Windows.Forms.Label();
            tbTriangleBase = new System.Windows.Forms.TextBox();
            label14 = new System.Windows.Forms.Label();
            lblTriangleResult = new System.Windows.Forms.Label();
            btnTriangleCancel = new System.Windows.Forms.Button();
            btnTriangleCalculate = new System.Windows.Forms.Button();
            label11 = new System.Windows.Forms.Label();
            rdoTriangleRound = new System.Windows.Forms.RadioButton();
            rdoTriangleArea = new System.Windows.Forms.RadioButton();
            timer1 = new System.Windows.Forms.Timer(components);
            kk.SuspendLayout();
            tabControl1.SuspendLayout();
            tabPage1.SuspendLayout();
            tabPage2.SuspendLayout();
            tabPage3.SuspendLayout();
            SuspendLayout();
            // 
            // btnMainMenu
            // 
            btnMainMenu.Image = Properties.Resources.pevious1;
            btnMainMenu.Location = new System.Drawing.Point(886, 57);
            btnMainMenu.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            btnMainMenu.Name = "btnMainMenu";
            btnMainMenu.Size = new System.Drawing.Size(146, 100);
            btnMainMenu.TabIndex = 19;
            btnMainMenu.Text = "หน้าจอหลัก";
            btnMainMenu.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            btnMainMenu.UseVisualStyleBackColor = true;
            btnMainMenu.Click += btnMainMenu_Click;
            // 
            // label1
            // 
            label1.BackColor = System.Drawing.Color.Yellow;
            label1.Font = new System.Drawing.Font("Segoe UI", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label1.ForeColor = System.Drawing.Color.Blue;
            label1.Location = new System.Drawing.Point(131, 57);
            label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(707, 82);
            label1.TabIndex = 18;
            label1.Text = "คำนวณรูปทรง";
            label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            label1.UseCompatibleTextRendering = true;
            // 
            // kk
            // 
            kk.Dock = System.Windows.Forms.DockStyle.Bottom;
            kk.ImageScalingSize = new System.Drawing.Size(24, 24);
            kk.Items.AddRange(new System.Windows.Forms.ToolStripItem[] { lblNameShow, lblDatetimeShow });
            kk.Location = new System.Drawing.Point(0, 720);
            kk.Name = "kk";
            kk.Padding = new System.Windows.Forms.Padding(0, 0, 3, 0);
            kk.Size = new System.Drawing.Size(1143, 30);
            kk.TabIndex = 51;
            kk.Text = "toolStrip1";
            // 
            // lblNameShow
            // 
            lblNameShow.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            lblNameShow.ForeColor = System.Drawing.Color.Blue;
            lblNameShow.Name = "lblNameShow";
            lblNameShow.Size = new System.Drawing.Size(70, 25);
            lblNameShow.Text = "Name?";
            // 
            // lblDatetimeShow
            // 
            lblDatetimeShow.Name = "lblDatetimeShow";
            lblDatetimeShow.Size = new System.Drawing.Size(90, 25);
            lblDatetimeShow.Text = "datetime?";
            // 
            // tabControl1
            // 
            tabControl1.Controls.Add(tabPage1);
            tabControl1.Controls.Add(tabPage2);
            tabControl1.Controls.Add(tabPage3);
            tabControl1.Location = new System.Drawing.Point(131, 172);
            tabControl1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            tabControl1.Name = "tabControl1";
            tabControl1.SelectedIndex = 0;
            tabControl1.Size = new System.Drawing.Size(707, 433);
            tabControl1.TabIndex = 52;
            // 
            // tabPage1
            // 
            tabPage1.Controls.Add(lblCircleResult);
            tabPage1.Controls.Add(btnCircleCancel);
            tabPage1.Controls.Add(btnCircleCalculate);
            tabPage1.Controls.Add(label4);
            tabPage1.Controls.Add(rdoCircleRound);
            tabPage1.Controls.Add(rdoCircleArea);
            tabPage1.Controls.Add(tbCircleRadius);
            tabPage1.Controls.Add(label6);
            tabPage1.Location = new System.Drawing.Point(4, 34);
            tabPage1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            tabPage1.Name = "tabPage1";
            tabPage1.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            tabPage1.Size = new System.Drawing.Size(699, 395);
            tabPage1.TabIndex = 0;
            tabPage1.Text = "วงกลม";
            tabPage1.UseVisualStyleBackColor = true;
            // 
            // lblCircleResult
            // 
            lblCircleResult.BackColor = System.Drawing.Color.Yellow;
            lblCircleResult.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            lblCircleResult.ForeColor = System.Drawing.Color.Red;
            lblCircleResult.Location = new System.Drawing.Point(31, 315);
            lblCircleResult.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            lblCircleResult.Name = "lblCircleResult";
            lblCircleResult.Size = new System.Drawing.Size(447, 52);
            lblCircleResult.TabIndex = 58;
            lblCircleResult.Text = "0.00";
            lblCircleResult.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnCircleCancel
            // 
            btnCircleCancel.Image = Properties.Resources.cancel;
            btnCircleCancel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            btnCircleCancel.Location = new System.Drawing.Point(517, 215);
            btnCircleCancel.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            btnCircleCancel.Name = "btnCircleCancel";
            btnCircleCancel.Size = new System.Drawing.Size(146, 85);
            btnCircleCancel.TabIndex = 57;
            btnCircleCancel.Text = "ยกเลิก";
            btnCircleCancel.UseVisualStyleBackColor = true;
            // 
            // btnCircleCalculate
            // 
            btnCircleCalculate.Image = Properties.Resources.calculator2;
            btnCircleCalculate.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            btnCircleCalculate.Location = new System.Drawing.Point(517, 120);
            btnCircleCalculate.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            btnCircleCalculate.Name = "btnCircleCalculate";
            btnCircleCalculate.Size = new System.Drawing.Size(146, 85);
            btnCircleCalculate.TabIndex = 56;
            btnCircleCalculate.Text = "คำนวณ";
            btnCircleCalculate.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            label4.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label4.Location = new System.Drawing.Point(31, 252);
            label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            label4.Name = "label4";
            label4.Size = new System.Drawing.Size(87, 65);
            label4.TabIndex = 55;
            label4.Text = "ผลลัพธ์";
            label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // rdoCircleRound
            // 
            rdoCircleRound.AutoSize = true;
            rdoCircleRound.Location = new System.Drawing.Point(31, 215);
            rdoCircleRound.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            rdoCircleRound.Name = "rdoCircleRound";
            rdoCircleRound.Size = new System.Drawing.Size(136, 29);
            rdoCircleRound.TabIndex = 54;
            rdoCircleRound.Text = "เส้นรอบวงกลม";
            rdoCircleRound.UseVisualStyleBackColor = true;
            // 
            // rdoCircleArea
            // 
            rdoCircleArea.AutoSize = true;
            rdoCircleArea.Checked = true;
            rdoCircleArea.Location = new System.Drawing.Point(31, 155);
            rdoCircleArea.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            rdoCircleArea.Name = "rdoCircleArea";
            rdoCircleArea.Size = new System.Drawing.Size(116, 29);
            rdoCircleArea.TabIndex = 53;
            rdoCircleArea.TabStop = true;
            rdoCircleArea.Text = "พื้นที่วงกลม";
            rdoCircleArea.UseVisualStyleBackColor = true;
            // 
            // tbCircleRadius
            // 
            tbCircleRadius.Location = new System.Drawing.Point(31, 85);
            tbCircleRadius.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            tbCircleRadius.Name = "tbCircleRadius";
            tbCircleRadius.Size = new System.Drawing.Size(445, 31);
            tbCircleRadius.TabIndex = 52;
            // 
            // label6
            // 
            label6.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label6.Location = new System.Drawing.Point(31, 22);
            label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            label6.Name = "label6";
            label6.Size = new System.Drawing.Size(87, 65);
            label6.TabIndex = 51;
            label6.Text = "ป้อนรัศมี";
            label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tabPage2
            // 
            tabPage2.Controls.Add(tbSquareHeight);
            tabPage2.Controls.Add(label13);
            tabPage2.Controls.Add(lblSquareResult);
            tabPage2.Controls.Add(btnSquareCancel);
            tabPage2.Controls.Add(btnSquareCalculate);
            tabPage2.Controls.Add(label8);
            tabPage2.Controls.Add(rdoSquareRound);
            tabPage2.Controls.Add(rdoSquareArea);
            tabPage2.Controls.Add(tbSquareWidth);
            tabPage2.Controls.Add(label9);
            tabPage2.Location = new System.Drawing.Point(4, 34);
            tabPage2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            tabPage2.Name = "tabPage2";
            tabPage2.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            tabPage2.Size = new System.Drawing.Size(699, 395);
            tabPage2.TabIndex = 1;
            tabPage2.Text = "สีเหลี่ยม";
            tabPage2.UseVisualStyleBackColor = true;
            // 
            // tbSquareHeight
            // 
            tbSquareHeight.Location = new System.Drawing.Point(214, 85);
            tbSquareHeight.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            tbSquareHeight.Name = "tbSquareHeight";
            tbSquareHeight.Size = new System.Drawing.Size(154, 31);
            tbSquareHeight.TabIndex = 60;
            // 
            // label13
            // 
            label13.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label13.Location = new System.Drawing.Point(214, 22);
            label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            label13.Name = "label13";
            label13.Size = new System.Drawing.Size(87, 65);
            label13.TabIndex = 59;
            label13.Text = "ป้อนยาว";
            label13.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblSquareResult
            // 
            lblSquareResult.BackColor = System.Drawing.Color.Yellow;
            lblSquareResult.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            lblSquareResult.ForeColor = System.Drawing.Color.Red;
            lblSquareResult.Location = new System.Drawing.Point(31, 315);
            lblSquareResult.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            lblSquareResult.Name = "lblSquareResult";
            lblSquareResult.Size = new System.Drawing.Size(447, 52);
            lblSquareResult.TabIndex = 58;
            lblSquareResult.Text = "0.00";
            lblSquareResult.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnSquareCancel
            // 
            btnSquareCancel.Image = Properties.Resources.cancel;
            btnSquareCancel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            btnSquareCancel.Location = new System.Drawing.Point(517, 215);
            btnSquareCancel.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            btnSquareCancel.Name = "btnSquareCancel";
            btnSquareCancel.Size = new System.Drawing.Size(146, 85);
            btnSquareCancel.TabIndex = 57;
            btnSquareCancel.Text = "ยกเลิก";
            btnSquareCancel.UseVisualStyleBackColor = true;
            // 
            // btnSquareCalculate
            // 
            btnSquareCalculate.Image = Properties.Resources.calculator2;
            btnSquareCalculate.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            btnSquareCalculate.Location = new System.Drawing.Point(517, 120);
            btnSquareCalculate.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            btnSquareCalculate.Name = "btnSquareCalculate";
            btnSquareCalculate.Size = new System.Drawing.Size(146, 85);
            btnSquareCalculate.TabIndex = 56;
            btnSquareCalculate.Text = "คำนวณ";
            btnSquareCalculate.UseVisualStyleBackColor = true;
            // 
            // label8
            // 
            label8.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label8.Location = new System.Drawing.Point(31, 252);
            label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            label8.Name = "label8";
            label8.Size = new System.Drawing.Size(87, 65);
            label8.TabIndex = 55;
            label8.Text = "ผลลัพธ์";
            label8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // rdoSquareRound
            // 
            rdoSquareRound.AutoSize = true;
            rdoSquareRound.Location = new System.Drawing.Point(31, 215);
            rdoSquareRound.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            rdoSquareRound.Name = "rdoSquareRound";
            rdoSquareRound.Size = new System.Drawing.Size(136, 29);
            rdoSquareRound.TabIndex = 54;
            rdoSquareRound.Text = "เส้นรอบวงกลม";
            rdoSquareRound.UseVisualStyleBackColor = true;
            // 
            // rdoSquareArea
            // 
            rdoSquareArea.AutoSize = true;
            rdoSquareArea.Checked = true;
            rdoSquareArea.Location = new System.Drawing.Point(31, 155);
            rdoSquareArea.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            rdoSquareArea.Name = "rdoSquareArea";
            rdoSquareArea.Size = new System.Drawing.Size(116, 29);
            rdoSquareArea.TabIndex = 53;
            rdoSquareArea.TabStop = true;
            rdoSquareArea.Text = "พื้นที่วงกลม";
            rdoSquareArea.UseVisualStyleBackColor = true;
            // 
            // tbSquareWidth
            // 
            tbSquareWidth.Location = new System.Drawing.Point(31, 85);
            tbSquareWidth.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            tbSquareWidth.Name = "tbSquareWidth";
            tbSquareWidth.Size = new System.Drawing.Size(154, 31);
            tbSquareWidth.TabIndex = 52;
            // 
            // label9
            // 
            label9.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label9.Location = new System.Drawing.Point(31, 22);
            label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            label9.Name = "label9";
            label9.Size = new System.Drawing.Size(87, 65);
            label9.TabIndex = 51;
            label9.Text = "ป้อนรัศมี";
            label9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tabPage3
            // 
            tabPage3.Controls.Add(tbTriangleCorner);
            tabPage3.Controls.Add(label15);
            tabPage3.Controls.Add(tbTriangleHeight);
            tabPage3.Controls.Add(label12);
            tabPage3.Controls.Add(tbTriangleBase);
            tabPage3.Controls.Add(label14);
            tabPage3.Controls.Add(lblTriangleResult);
            tabPage3.Controls.Add(btnTriangleCancel);
            tabPage3.Controls.Add(btnTriangleCalculate);
            tabPage3.Controls.Add(label11);
            tabPage3.Controls.Add(rdoTriangleRound);
            tabPage3.Controls.Add(rdoTriangleArea);
            tabPage3.Location = new System.Drawing.Point(4, 34);
            tabPage3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            tabPage3.Name = "tabPage3";
            tabPage3.Size = new System.Drawing.Size(699, 395);
            tabPage3.TabIndex = 2;
            tabPage3.Text = "สามเหลี่ยมมุมฉาก";
            tabPage3.UseVisualStyleBackColor = true;
            // 
            // tbTriangleCorner
            // 
            tbTriangleCorner.Location = new System.Drawing.Point(384, 75);
            tbTriangleCorner.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            tbTriangleCorner.Name = "tbTriangleCorner";
            tbTriangleCorner.Size = new System.Drawing.Size(154, 31);
            tbTriangleCorner.TabIndex = 66;
            // 
            // label15
            // 
            label15.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label15.Location = new System.Drawing.Point(384, 12);
            label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            label15.Name = "label15";
            label15.Size = new System.Drawing.Size(194, 65);
            label15.TabIndex = 65;
            label15.Text = "ป้อนด้านตรงข้ามมุมฉาก";
            label15.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            label15.Click += label15_Click;
            // 
            // tbTriangleHeight
            // 
            tbTriangleHeight.Location = new System.Drawing.Point(211, 75);
            tbTriangleHeight.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            tbTriangleHeight.Name = "tbTriangleHeight";
            tbTriangleHeight.Size = new System.Drawing.Size(154, 31);
            tbTriangleHeight.TabIndex = 64;
            // 
            // label12
            // 
            label12.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label12.Location = new System.Drawing.Point(211, 12);
            label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            label12.Name = "label12";
            label12.Size = new System.Drawing.Size(87, 65);
            label12.TabIndex = 63;
            label12.Text = "ป้อนยาว";
            label12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tbTriangleBase
            // 
            tbTriangleBase.Location = new System.Drawing.Point(29, 75);
            tbTriangleBase.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            tbTriangleBase.Name = "tbTriangleBase";
            tbTriangleBase.Size = new System.Drawing.Size(154, 31);
            tbTriangleBase.TabIndex = 62;
            // 
            // label14
            // 
            label14.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label14.Location = new System.Drawing.Point(29, 12);
            label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            label14.Name = "label14";
            label14.Size = new System.Drawing.Size(87, 65);
            label14.TabIndex = 61;
            label14.Text = "ป้อนรัศมี";
            label14.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblTriangleResult
            // 
            lblTriangleResult.BackColor = System.Drawing.Color.Yellow;
            lblTriangleResult.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            lblTriangleResult.ForeColor = System.Drawing.Color.Red;
            lblTriangleResult.Location = new System.Drawing.Point(31, 315);
            lblTriangleResult.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            lblTriangleResult.Name = "lblTriangleResult";
            lblTriangleResult.Size = new System.Drawing.Size(447, 52);
            lblTriangleResult.TabIndex = 58;
            lblTriangleResult.Text = "0.00";
            lblTriangleResult.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnTriangleCancel
            // 
            btnTriangleCancel.Image = Properties.Resources.cancel;
            btnTriangleCancel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            btnTriangleCancel.Location = new System.Drawing.Point(517, 215);
            btnTriangleCancel.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            btnTriangleCancel.Name = "btnTriangleCancel";
            btnTriangleCancel.Size = new System.Drawing.Size(146, 85);
            btnTriangleCancel.TabIndex = 57;
            btnTriangleCancel.Text = "ยกเลิก";
            btnTriangleCancel.UseVisualStyleBackColor = true;
            // 
            // btnTriangleCalculate
            // 
            btnTriangleCalculate.Image = Properties.Resources.calculator2;
            btnTriangleCalculate.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            btnTriangleCalculate.Location = new System.Drawing.Point(517, 120);
            btnTriangleCalculate.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            btnTriangleCalculate.Name = "btnTriangleCalculate";
            btnTriangleCalculate.Size = new System.Drawing.Size(146, 85);
            btnTriangleCalculate.TabIndex = 56;
            btnTriangleCalculate.Text = "คำนวณ";
            btnTriangleCalculate.UseVisualStyleBackColor = true;
            // 
            // label11
            // 
            label11.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label11.Location = new System.Drawing.Point(31, 252);
            label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            label11.Name = "label11";
            label11.Size = new System.Drawing.Size(87, 65);
            label11.TabIndex = 55;
            label11.Text = "ผลลัพธ์";
            label11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // rdoTriangleRound
            // 
            rdoTriangleRound.AutoSize = true;
            rdoTriangleRound.Location = new System.Drawing.Point(31, 215);
            rdoTriangleRound.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            rdoTriangleRound.Name = "rdoTriangleRound";
            rdoTriangleRound.Size = new System.Drawing.Size(136, 29);
            rdoTriangleRound.TabIndex = 54;
            rdoTriangleRound.Text = "เส้นรอบวงกลม";
            rdoTriangleRound.UseVisualStyleBackColor = true;
            // 
            // rdoTriangleArea
            // 
            rdoTriangleArea.AutoSize = true;
            rdoTriangleArea.Checked = true;
            rdoTriangleArea.Location = new System.Drawing.Point(31, 155);
            rdoTriangleArea.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            rdoTriangleArea.Name = "rdoTriangleArea";
            rdoTriangleArea.Size = new System.Drawing.Size(116, 29);
            rdoTriangleArea.TabIndex = 53;
            rdoTriangleArea.TabStop = true;
            rdoTriangleArea.Text = "พื้นที่วงกลม";
            rdoTriangleArea.UseVisualStyleBackColor = true;
            // 
            // timer1
            // 
            timer1.Tick += timer1_Tick;
            // 
            // FrmShape
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            ClientSize = new System.Drawing.Size(1143, 750);
            Controls.Add(tabControl1);
            Controls.Add(kk);
            Controls.Add(btnMainMenu);
            Controls.Add(label1);
            Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            Name = "FrmShape";
            Text = "FrmShape";
            kk.ResumeLayout(false);
            kk.PerformLayout();
            tabControl1.ResumeLayout(false);
            tabPage1.ResumeLayout(false);
            tabPage1.PerformLayout();
            tabPage2.ResumeLayout(false);
            tabPage2.PerformLayout();
            tabPage3.ResumeLayout(false);
            tabPage3.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Button btnMainMenu;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ToolStrip kk;
        private System.Windows.Forms.ToolStripLabel lblNameShow;
        private System.Windows.Forms.ToolStripLabel lblDatetimeShow;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Label lblCircleResult;
        private System.Windows.Forms.Button btnCircleCancel;
        private System.Windows.Forms.Button btnCircleCalculate;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.RadioButton rdoCircleRound;
        private System.Windows.Forms.RadioButton rdoCircleArea;
        private System.Windows.Forms.TextBox tbCircleRadius;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TextBox tbSquareHeight;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label lblSquareResult;
        private System.Windows.Forms.Button btnSquareCancel;
        private System.Windows.Forms.Button btnSquareCalculate;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.RadioButton rdoSquareRound;
        private System.Windows.Forms.RadioButton rdoSquareArea;
        private System.Windows.Forms.TextBox tbSquareWidth;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TextBox tbTriangleCorner;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox tbTriangleHeight;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox tbTriangleBase;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label lblTriangleResult;
        private System.Windows.Forms.Button btnTriangleCancel;
        private System.Windows.Forms.Button btnTriangleCalculate;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.RadioButton rdoTriangleRound;
        private System.Windows.Forms.RadioButton rdoTriangleArea;
        private System.Windows.Forms.Timer timer1;
    }
}