﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyProjectDTI02
{
    public partial class FrmRegister : Form
    {
        public FrmRegister()
        {
            InitializeComponent();
            //nameshow มาแสดงที่ label lblnameshow
            lblNameShow.Text = ShareDate.name_show;

            //สั่ง time ให้ Start
            timer1.Start();
        }

        private void btnMainMenu_Click(object sender, EventArgs e)
        {
            FrmMainMenu frmMainMenu = new FrmMainMenu();
            frmMainMenu.Show();
            this.Hide();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            //show time date realtime
            CultureInfo culture = new CultureInfo("th-TH");
            lblDatetimeShow.Text = DateTime.Now.ToString("วันที่" + "dd เดือน MMMM พ.ศ. yyyy HH:mm:ss" + "  น.", culture);
        }
    }
}
