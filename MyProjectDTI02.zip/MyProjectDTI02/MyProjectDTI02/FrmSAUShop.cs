﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Reflection.Metadata;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyProjectDTI02
{
    public partial class FrmSAUShop : Form
    {
        public FrmSAUShop()
        {
            InitializeComponent();
            //nameshow มาแสดงที่ label lblnameshow
            lblNameShow.Text = ShareDate.name_show;

            //สั่ง time ให้ Start
            timer1.Start();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void FrmSAUShop_Load(object sender, EventArgs e)
        {
            //เมื่อ From ถูกโหลดขึ้นมา
            //ให้เลือกรายการแรกของ comboBox ถูกเลือก
            cbbSale.SelectedIndex = 0;
        }

        private void btMainMenu_Click(object sender, EventArgs e)
        {
            FrmMainMenu frmMainMenu = new FrmMainMenu();
            frmMainMenu.Show();
            this.Hide();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            //show time date realtime
            CultureInfo culture = new CultureInfo("th-TH");
            lblDatetimeShow1.Text = DateTime.Now.ToString("วันที่" + "dd เดือน MMMM พ.ศ. yyyy HH:mm:ss" + "  น.", culture);
        }

        private void cbbSale_KeyPress(object sender, KeyPressEventArgs e)
        {
            //ให้ยกเลิกทุกปุ่มใดๆ ที่ผู้ใช้กดบนคีย์บอร์ด
            e.Handled = true;
        }

        private void chkPen_Click(object sender, EventArgs e)
        {
            //ตรวจสอบว่าติ๊กหรือไม่ติ๊ก
            //หากติ๊ก ให้ช่องป้อนจำนวนไม่ได้ - หากไม่ติ๊ก ให้ช่องป้อนจำนวนเป็น 0 ช่องคิดเงินเป็น 0 และช่องป้อนจำนวนใช้ไม่ได้
            if (chkPen.Checked == true)
            {
                tbPen.Enabled = true;
            }
            else
            {
                tbPen.Text = "0";
                lblPenPay.Text = "0.00";
                tbPen.Enabled = false;
            }
        }

        private void tbPen_KeyPress(object sender, KeyPressEventArgs e)
        {
            //ถ้าไม่ใช่ปุ่มที่ผู้ใช้งานกด 
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled |= true;
            }


        }

        private void tbPen_KeyUp(object sender, KeyEventArgs e)
        {
            if (tbPen.Text.Length == 0)
            {
                ShareDate.showWarningMSG("ช่องจำนวนปากกาต้องไม่ว่าง");
            }
            else
            {
                //ดังนั้นปุ่มที่กดเป็นตัวเลข หรือ Control ต่างๆ ให้เอาจำนวนที่ผู้ใช้ป้อนไปคูรราคาและแสดงที่ lable ข้างหลัง
                double pay = double.Parse(tbPen.Text) * 5;
                lblPenPay.Text = pay.ToString("#,##0.00");
            }

        }

        private void chkPencil_Click(object sender, EventArgs e)
        {
            //ตรวจสอบว่าติ๊กหรือไม่ติ๊ก
            //หากติ๊ก ให้ช่องป้อนจำนวนไม่ได้ - หากไม่ติ๊ก ให้ช่องป้อนจำนวนเป็น 0 ช่องคิดเงินเป็น 0 และช่องป้อนจำนวนใช้ไม่ได้
            if (chkPencil.Checked == true)
            {
                tbPencil.Enabled = true;
            }
            else
            {
                tbPencil.Text = "0";
                lblPencilPay.Text = "0.00";
                tbPencil.Enabled = false;
            }
        }

        private void tbPencil_KeyPress(object sender, KeyPressEventArgs e)
        {
            //ถ้าไม่ใช่ปุ่มที่ผู้ใช้งานกด 
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled |= true;
            }
        }

        private void tbPencil_KeyUp(object sender, KeyEventArgs e)
        {
            if (tbPencil.Text.Length == 0)
            {
                ShareDate.showWarningMSG("ช่องจำนวนปากกาต้องไม่ว่าง");
            }
            else
            {
                //ดังนั้นปุ่มที่กดเป็นตัวเลข หรือ Control ต่างๆ ให้เอาจำนวนที่ผู้ใช้ป้อนไปคูรราคาและแสดงที่ lable ข้างหลัง
                double pay = double.Parse(tbPencil.Text) * 1.50;
                lblPencilPay.Text = pay.ToString("#,##0.00");
            }

        }

        private void chkRubber_Click(object sender, EventArgs e)
        {
            //ตรวจสอบว่าติ๊กหรือไม่ติ๊ก
            //หากติ๊ก ให้ช่องป้อนจำนวนไม่ได้ - หากไม่ติ๊ก ให้ช่องป้อนจำนวนเป็น 0 ช่องคิดเงินเป็น 0 และช่องป้อนจำนวนใช้ไม่ได้
            if (chkRubber.Checked == true)
            {
                tbRubber.Enabled = true;
            }
            else
            {
                tbRubber.Text = "0";
                lblRubberPay.Text = "0.00";
                tbRubber.Enabled = false;
            }
        }

        private void tbRubber_KeyPress(object sender, KeyPressEventArgs e)
        {
            //ถ้าไม่ใช่ปุ่มที่ผู้ใช้งานกด 
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled |= true;
            }
        }

        private void tbRubber_KeyUp(object sender, KeyEventArgs e)
        {
            if (tbRubber.Text.Length == 0)
            {
                ShareDate.showWarningMSG("ช่องจำนวนปากกาต้องไม่ว่าง");
            }
            else
            {
                //ดังนั้นปุ่มที่กดเป็นตัวเลข หรือ Control ต่างๆ ให้เอาจำนวนที่ผู้ใช้ป้อนไปคูรราคาและแสดงที่ lable ข้างหลัง
                double pay = double.Parse(tbRubber.Text) * 2.50;
                lblRubberPay.Text = pay.ToString("#,##0.00");
            }

        }

        private void chkRuler_Click(object sender, EventArgs e)
        {

            //ตรวจสอบว่าติ๊กหรือไม่ติ๊ก
            //หากติ๊ก ให้ช่องป้อนจำนวนไม่ได้ - หากไม่ติ๊ก ให้ช่องป้อนจำนวนเป็น 0 ช่องคิดเงินเป็น 0 และช่องป้อนจำนวนใช้ไม่ได้
            if (chkRuler.Checked == true)
            {
                tbRuler.Enabled = true;
            }
            else
            {
                tbRuler.Text = "0";
                lblRulerPay.Text = "0.00";
                tbRuler.Enabled = false;
            }
        }

        private void tbRuler_KeyPress(object sender, KeyPressEventArgs e)
        {

            //ถ้าไม่ใช่ปุ่มที่ผู้ใช้งานกด 
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled |= true;
            }
        }

        private void tbRuler_KeyUp(object sender, KeyEventArgs e)
        {
            if (tbRuler.Text.Length == 0)
            {
                ShareDate.showWarningMSG("ช่องจำนวนปากกาต้องไม่ว่าง");
            }
            else
            {
                //ดังนั้นปุ่มที่กดเป็นตัวเลข หรือ Control ต่างๆ ให้เอาจำนวนที่ผู้ใช้ป้อนไปคูรราคาและแสดงที่ lable ข้างหลัง
                double pay = double.Parse(tbRuler.Text) * 5;
                lblRulerPay.Text = pay.ToString("#,##0.00");
            }

        }

        private void chkBook_Click(object sender, EventArgs e)
        {


            //ตรวจสอบว่าติ๊กหรือไม่ติ๊ก
            //หากติ๊ก ให้ช่องป้อนจำนวนไม่ได้ - หากไม่ติ๊ก ให้ช่องป้อนจำนวนเป็น 0 ช่องคิดเงินเป็น 0 และช่องป้อนจำนวนใช้ไม่ได้
            if (chkBook.Checked == true)
            {
                tbBook.Enabled = true;
            }
            else
            {
                tbBook.Text = "0";
                lblBookPay.Text = "0.00";
                tbBook.Enabled = false;
            }
        }

        private void tbBook_KeyPress(object sender, KeyPressEventArgs e)
        {

            //ถ้าไม่ใช่ปุ่มที่ผู้ใช้งานกด 
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled |= true;
            }
        }

        private void tbBook_KeyUp(object sender, KeyEventArgs e)
        {
            if (tbBook.Text.Length == 0)
            {
                ShareDate.showWarningMSG("ช่องจำนวนปากกาต้องไม่ว่าง");
            }
            else
            {
                //ดังนั้นปุ่มที่กดเป็นตัวเลข หรือ Control ต่างๆ ให้เอาจำนวนที่ผู้ใช้ป้อนไปคูรราคาและแสดงที่ lable ข้างหลัง
                double pay = double.Parse(tbBook.Text) * 5;
                lblBookPay.Text = pay.ToString("#,##0.00");
            }

        }

        private void btCalculate_Click(object sender, EventArgs e)
        {
            //นำคิดเป็นเงินของแต่ละสิ้นค้ามารวมกัน และตรวจสอบว่ามีส่วนลดหรือไม่อย่างไร แล้วคำนวณ และแสดงผล
            double payTotalBeforeSale = double.Parse(lblPenPay.Text) +
                                        double.Parse(lblPencilPay.Text) +
                                        double.Parse(lblRubberPay.Text) +
                                        double.Parse(lblRulerPay.Text) +
                                        double.Parse(lblBookPay.Text);
            //ตรวจสอบเพื่อคำนวณส่วนลด
            double payTotalAfterSale;
            if (cbbSale.SelectedIndex == 0)
            {
                payTotalAfterSale = payTotalBeforeSale;
            }
            else if (cbbSale.SelectedIndex == 1)
            {
                payTotalAfterSale = payTotalBeforeSale - (payTotalBeforeSale * 10 / 100);
            }
            else if (cbbSale.SelectedIndex == 2)
            {
                payTotalAfterSale = payTotalBeforeSale - (payTotalBeforeSale * 7 / 100);
            }
            else
            {
                payTotalAfterSale = payTotalBeforeSale - (payTotalBeforeSale * 5 / 100);
            }
            lblTotolPay.Text = payTotalAfterSale.ToString("#,##0.00");
        }

        private void btCancel_Click(object sender, EventArgs e)
        {
            //ทุกอย่างกลับเป็นเหมือนเดิม
            chkPen.Checked = false;
            chkPencil.Checked = false;
            chkRubber.Checked = false;
            chkRuler.Checked = false;
            chkBook.Checked = false;

            tbPen.Text = "0";
            tbPen.Enabled = false;
            tbPencil.Text = "0";
            tbPencil.Enabled = false;
            tbRubber.Text = "0";
            tbRubber.Enabled = false;
            tbRuler.Text = "0";
            tbRuler.Enabled = false;
            tbBook.Text = "0";
            tbBook.Enabled = false;

            lblPenPay.Text = "0";
            lblPencilPay.Text = "0";
            lblRubberPay.Text = "0";
            lblRulerPay.Text = "0";
            lblBookPay.Text = "0";
            

            cbbSale.SelectedIndex = 0;

            lblTotolPay.Text = "0.00";
           

        }
    }
}
