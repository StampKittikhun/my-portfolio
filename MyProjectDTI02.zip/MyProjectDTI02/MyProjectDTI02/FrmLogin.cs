﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyProjectDTI02
{
    public partial class FrmLogin : Form
    {
        public FrmLogin()
        {
            InitializeComponent();
        }

        private void tbUsername_KeyPress(object sender, KeyPressEventArgs e)
        {
            //ตรวจสอบปุ่มที่กดว่าไม่ใช่อักษรแลพคอนโทรล
            if (!char.IsLetter(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
            //ตรวจสอบว่า ถ้าเป็นปุ่ม Enter ให้เคอร์เซอร์ไปกระพริบอยู่ที่ช่องรหัสผ่าน
            if (e.KeyChar == (char)13)
            {
                tbPassword.Focus();
            }
        }

        private void tbPassword_KeyPress(object sender, KeyPressEventArgs e)
        // ตรวจสอบปุ่มที่กดว่าไม่ใช่ปุมตัวเลขคอนโทรล
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
            //ตรวจสอบว่า ถ้าเป็นปุ่ม Enter จะให้ไปเรียกโค๊ดของปุ่ม btnLogin_click ทำงาน
            if (e.KeyChar == (char)13)
            {
                btLogin.PerformClick();
            }
        }

        private void btLogin_Click(object sender, EventArgs e)
        {
            // validate 

            //if (tbUsername.Text == "")
            if (tbUsername.Text.Length == 0)
            {
                ShareDate.showWarningMSG("ป้อน username ด้วย........");
            }
            else if (tbPassword.Text.Length == 0)
                ShareDate.showWarningMSG("ป้อน username ด้วย........");
            else if (tbPassword.Text.Length < 6)
            {
                ShareDate.showWarningMSG("ป้อน username/passwordc ด้วย........");
            }
            else if (tbUsername.Text == "SAU" && tbPassword.Text == "123456789")
            {
                //เอาชื่อประเภท เก็บในตัวแปล
                if (rdoStudent.Checked == true)
                {
                    ShareDate.name_show = "SAU-Student";
                }
                else
                {
                    ShareDate.name_show = "SAU-Teacher";
                }
                //ป้อนหน้าจอ FrmMainMenu

                FrmMainMenu frmMainMenu = new FrmMainMenu();
                frmMainMenu.Show();
                this.Hide();
            }
            else
            {
                //show Msg username /password ผิด
                ShareDate.showWarningMSG(" username/password ไม่ถูกต้อง.....");
            }


        }

        private void btExit_Click(object sender, EventArgs e)
        {
            //ให้กลับเป็นเหมือนเดิม 
            tbUsername.Clear();
            tbPassword.Clear();
            rdoStudent.Checked = true;
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            //แสดง MSG ถามผู้ใช้ก่อนว่าออกจากระบบไหม Yes ปิดโปรแกรม NO ไม่ปิดโปรแกรม
            if(MessageBox.Show("ต้องการออกจากระบบไหม","ยืนยัน",MessageBoxButtons.YesNo,MessageBoxIcon.Question) == DialogResult.Yes)
            {
                //ปิดโปรแกรม
                Application.Exit();
            }
        }
    }
}
