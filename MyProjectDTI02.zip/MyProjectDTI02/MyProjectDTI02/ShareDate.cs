﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyProjectDTI02
{
     internal class ShareDate
    {
        public static string name_show = "";

        public static void showWarningMSG(string msg)
        {
            MessageBox.Show(
                 msg,
                 "คำเตือน",
                 MessageBoxButtons.OK,
                 MessageBoxIcon.Warning

            );
        }
        public static void inputNumberOnly(KeyPressEventArgs e)
        {
            //ตรวจสอบถ้าไม่ใช่ปุ่มตัวเลขให้ยกเลิก 
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }
    }
}
