﻿
namespace MyProjectDTI02
{
    partial class FrmRejisterResolt
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.pbStuImage = new System.Windows.Forms.PictureBox();
            this.lblStuSelectSubject = new System.Windows.Forms.Label();
            this.lblStuLevel = new System.Windows.Forms.Label();
            this.lblStuType = new System.Windows.Forms.Label();
            this.lblStuName = new System.Windows.Forms.Label();
            this.lblStuId = new System.Windows.Forms.Label();
            this.lblRegisterDate = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.btnOk = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pbStuImage)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Segoe UI", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.Color.Blue;
            this.label1.Location = new System.Drawing.Point(59, -6);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(314, 75);
            this.label1.TabIndex = 0;
            this.label1.Text = "ผลการลงทะเบียนเรียน";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pbStuImage
            // 
            this.pbStuImage.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbStuImage.Location = new System.Drawing.Point(131, 63);
            this.pbStuImage.Name = "pbStuImage";
            this.pbStuImage.Size = new System.Drawing.Size(157, 162);
            this.pbStuImage.TabIndex = 14;
            this.pbStuImage.TabStop = false;
            // 
            // lblStuSelectSubject
            // 
            this.lblStuSelectSubject.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblStuSelectSubject.ForeColor = System.Drawing.Color.Lime;
            this.lblStuSelectSubject.Location = new System.Drawing.Point(230, 429);
            this.lblStuSelectSubject.Name = "lblStuSelectSubject";
            this.lblStuSelectSubject.Size = new System.Drawing.Size(89, 23);
            this.lblStuSelectSubject.TabIndex = 54;
            this.lblStuSelectSubject.Text = "xxxxxxxxxxxxx";
            // 
            // lblStuLevel
            // 
            this.lblStuLevel.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblStuLevel.ForeColor = System.Drawing.Color.Lime;
            this.lblStuLevel.Location = new System.Drawing.Point(230, 397);
            this.lblStuLevel.Name = "lblStuLevel";
            this.lblStuLevel.Size = new System.Drawing.Size(89, 23);
            this.lblStuLevel.TabIndex = 53;
            this.lblStuLevel.Text = "xxxxxxxxxxxxx";
            // 
            // lblStuType
            // 
            this.lblStuType.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblStuType.ForeColor = System.Drawing.Color.Lime;
            this.lblStuType.Location = new System.Drawing.Point(230, 355);
            this.lblStuType.Name = "lblStuType";
            this.lblStuType.Size = new System.Drawing.Size(89, 23);
            this.lblStuType.TabIndex = 52;
            this.lblStuType.Text = "xxxxxxxxxxxxx";
            // 
            // lblStuName
            // 
            this.lblStuName.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblStuName.ForeColor = System.Drawing.Color.Lime;
            this.lblStuName.Location = new System.Drawing.Point(230, 318);
            this.lblStuName.Name = "lblStuName";
            this.lblStuName.Size = new System.Drawing.Size(89, 23);
            this.lblStuName.TabIndex = 51;
            this.lblStuName.Text = "xxxxxxxxxxxxx";
            // 
            // lblStuId
            // 
            this.lblStuId.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblStuId.ForeColor = System.Drawing.Color.Lime;
            this.lblStuId.Location = new System.Drawing.Point(230, 280);
            this.lblStuId.Name = "lblStuId";
            this.lblStuId.Size = new System.Drawing.Size(89, 23);
            this.lblStuId.TabIndex = 50;
            this.lblStuId.Text = "xxxxxxxxxxxxx";
            // 
            // lblRegisterDate
            // 
            this.lblRegisterDate.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblRegisterDate.ForeColor = System.Drawing.Color.Lime;
            this.lblRegisterDate.Location = new System.Drawing.Point(230, 247);
            this.lblRegisterDate.Name = "lblRegisterDate";
            this.lblRegisterDate.Size = new System.Drawing.Size(89, 23);
            this.lblRegisterDate.TabIndex = 49;
            this.lblRegisterDate.Text = "xxxxxxxxxxxxx";
            // 
            // label14
            // 
            this.label14.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label14.Location = new System.Drawing.Point(90, 341);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(112, 35);
            this.label14.TabIndex = 48;
            this.label14.Text = "ประเภทนักเรียน";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label9
            // 
            this.label9.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label9.Location = new System.Drawing.Point(90, 420);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(112, 29);
            this.label9.TabIndex = 47;
            this.label9.Text = "รายวิชาที่ลงทะเบียน";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label12
            // 
            this.label12.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label12.Location = new System.Drawing.Point(90, 271);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(112, 39);
            this.label12.TabIndex = 44;
            this.label12.Text = "เลขประจำตัวนักเรียน";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label10
            // 
            this.label10.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label10.Location = new System.Drawing.Point(90, 385);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(81, 35);
            this.label10.TabIndex = 46;
            this.label10.Text = "ระดับชั้น";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label13
            // 
            this.label13.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label13.Location = new System.Drawing.Point(90, 302);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(81, 39);
            this.label13.TabIndex = 43;
            this.label13.Text = "ชื่อ-นามสกุล";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label11
            // 
            this.label11.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label11.Location = new System.Drawing.Point(90, 237);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(81, 39);
            this.label11.TabIndex = 45;
            this.label11.Text = "วันที่ลงทะเบียน";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // btnOk
            // 
            this.btnOk.Image = global::MyProjectDTI02.Properties.Resources.ok;
            this.btnOk.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnOk.Location = new System.Drawing.Point(90, 464);
            this.btnOk.Name = "btnOk";
            this.btnOk.Size = new System.Drawing.Size(102, 51);
            this.btnOk.TabIndex = 55;
            this.btnOk.Text = "ตกลง";
            this.btnOk.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnOk.UseVisualStyleBackColor = true;
            // 
            // FrmRejisterResolt
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(435, 532);
            this.Controls.Add(this.btnOk);
            this.Controls.Add(this.lblStuSelectSubject);
            this.Controls.Add(this.lblStuLevel);
            this.Controls.Add(this.lblStuType);
            this.Controls.Add(this.lblStuName);
            this.Controls.Add(this.lblStuId);
            this.Controls.Add(this.lblRegisterDate);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.pbStuImage);
            this.Controls.Add(this.label1);
            this.Name = "FrmRejisterResolt";
            this.Text = "FrmRejisterResolt";
            ((System.ComponentModel.ISupportInitialize)(this.pbStuImage)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pbStuImage;
        private System.Windows.Forms.Label lblStuSelectSubject;
        private System.Windows.Forms.Label lblStuLevel;
        private System.Windows.Forms.Label lblStuType;
        private System.Windows.Forms.Label lblStuName;
        private System.Windows.Forms.Label lblStuId;
        private System.Windows.Forms.Label lblRegisterDate;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button btnOk;
    }
}