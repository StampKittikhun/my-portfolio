﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Globalization;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyProjectDTI02
{
    public partial class FrmLotto : Form
    {
        public FrmLotto()
        {
            InitializeComponent();
            //nameshow มาแสดงที่ label lblnameshow
            lblNameShow.Text = ShareDate.name_show;

            //สั่ง time ให้ Start
            timer1.Start();
        }

        private void btnMainMenu_Click(object sender, EventArgs e)
        {
            FrmMainMenu frmMainMenu = new FrmMainMenu();
            frmMainMenu.Show();
            this.Hide();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            //show time date realtime
            CultureInfo culture = new CultureInfo("th-TH");
            lblDatetimeShow.Text = DateTime.Now.ToString("วันที่" + "dd เดือน MMMM พ.ศ. yyyy HH:mm:ss" + "  น.", culture);
        }

        private void rdoCloseLotto_Click(object sender, EventArgs e)
        {
            //ตรวจสอบว่ามันถูกเลือกหรือไม่ ถ้าถูกเลือกให้เปิดการใช้งานของ Button ออกรางวัล
            if (rdoCloseLotto.Checked == true)
            {
                btnLotto1.Enabled = true;
                btnLotto3on.Enabled = true;
                btnLotto3Down.Enabled = true;
                btnLotto2Down.Enabled = true;
            }
        }

        private void rdoOpenLotto_Click(object sender, EventArgs e)
        {

            //ตรวจสอบว่ามันถูกเลือกหรือไม่ ถ้าถูกเลือกให้เปิดการใช้งานของ Button ออกรางวัล
            if (rdoCloseLotto.Checked == true)
            {
                btnLotto1.Enabled = false;
                btnLotto3on.Enabled = false;
                btnLotto3Down.Enabled = false;
                btnLotto2Down.Enabled = false;
                lblLotto1.Text = "??????";
                lblLotto3On1.Text = "???";
                lblLotto3On2.Text = "???";
                lblLotto3Down1.Text = "???";
                lblLotto3Down2.Text = "???";
                lblLotto2Down.Text = "??";
                dtpLottoDate.Value = DateTime.Now;
            }
        }

        private void btnLotto1_Click(object sender, EventArgs e)
        {
            //ตรวจสอบก่อนว่าเป็นวันที่ 1 กับ 16 หรือ
            if (dtpLottoDate.Value.Day != 1 && dtpLottoDate.Value.Day != 16)
            {
                ShareDate.showWarningMSG("หวยออกเฉพาะวันที่ 1 หรือ 16 เท่านั้นจ้าาา.....");
            }
            else
            {
                //ออกหวย....
                Random random = new Random();
                //คำสั่ง next จะสุ่มเลขตั้งแต่ 0 ถึง n-1
                string lotto = random.Next(1000000).ToString("000000");
                lblLotto1.Text = lotto;

            }
        }

        private void btnLotto3on_Click(object sender, EventArgs e)
        {

            //ตรวจสอบก่อนว่าเป็นวันที่ 1 กับ 16 หรือ
            if (dtpLottoDate.Value.Day != 1 && dtpLottoDate.Value.Day != 16)
            {
                ShareDate.showWarningMSG("หวยออกเฉพาะวันที่ 1 หรือ 16 เท่านั้นจ้าาา.....");
            }
            else
            {
                //ออกหวย....
                Random random = new Random();
                //คำสั่ง next จะสุ่มเลขตั้งแต่ 0 ถึง n-1
                string lotto = random.Next(1000).ToString("000");
                lblLotto3On1.Text = lotto;
                lotto = random.Next(1000).ToString("000");
                lblLotto3On2.Text = lotto;
            }
        }

        private void btnLotto3Down_Click(object sender, EventArgs e)
        {

            //ตรวจสอบก่อนว่าเป็นวันที่ 1 กับ 16 หรือ
            if (dtpLottoDate.Value.Day != 1 && dtpLottoDate.Value.Day != 16)
            {
                ShareDate.showWarningMSG("หวยออกเฉพาะวันที่ 1 หรือ 16 เท่านั้นจ้าาา.....");
            }
            else
            {
                //ออกหวย....
                Random random = new Random();
                //คำสั่ง next จะสุ่มเลขตั้งแต่ 0 ถึง n-1
                string lotto = random.Next(1000).ToString("000");
                lblLotto3Down1.Text = lotto;
                lotto = random.Next(1000).ToString("000");
                lblLotto3Down2.Text = lotto;
            }
        }

        private void btnLotto2Down_Click(object sender, EventArgs e)
        {
            //ตรวจสอบก่อนว่าเป็นวันที่ 1 กับ 16 หรือ
            if (dtpLottoDate.Value.Day != 1 && dtpLottoDate.Value.Day != 16)
            {
                ShareDate.showWarningMSG("หวยออกเฉพาะวันที่ 1 หรือ 16 เท่านั้นจ้าาา.....");
            }
            else
            {
                //ออกหวย....
                Random random = new Random();
                //คำสั่ง next จะสุ่มเลขตั้งแต่ 0 ถึง n-1
                string lotto = random.Next(100).ToString("00");
                lblLotto2Down.Text = lotto;

            }
        }
    }
}
