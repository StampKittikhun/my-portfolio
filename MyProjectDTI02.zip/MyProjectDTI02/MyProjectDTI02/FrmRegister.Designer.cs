﻿
namespace MyProjectDTI02
{
    partial class FrmRegister
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            label3 = new System.Windows.Forms.Label();
            rdoStuFund = new System.Windows.Forms.RadioButton();
            rdoStuNormal = new System.Windows.Forms.RadioButton();
            label2 = new System.Windows.Forms.Label();
            lsbStuSubject = new System.Windows.Forms.ListBox();
            label1 = new System.Windows.Forms.Label();
            pbStuImage = new System.Windows.Forms.PictureBox();
            mcdRegisterDate = new System.Windows.Forms.MonthCalendar();
            cbbStuLevel = new System.Windows.Forms.ComboBox();
            tbStuName = new System.Windows.Forms.TextBox();
            label4 = new System.Windows.Forms.Label();
            tbStuID = new System.Windows.Forms.TextBox();
            label5 = new System.Windows.Forms.Label();
            btnMainMenu = new System.Windows.Forms.Button();
            label6 = new System.Windows.Forms.Label();
            btnSelectStuImage = new System.Windows.Forms.Button();
            btnSelectOne = new System.Windows.Forms.Button();
            btnSelectAll = new System.Windows.Forms.Button();
            btnUnSelectOne = new System.Windows.Forms.Button();
            lsbStuSelectSubject = new System.Windows.Forms.ListBox();
            btnEnd = new System.Windows.Forms.Button();
            btnRegister = new System.Windows.Forms.Button();
            btnCancel = new System.Windows.Forms.Button();
            chkConfirm = new System.Windows.Forms.CheckBox();
            kk = new System.Windows.Forms.ToolStrip();
            lblNameShow = new System.Windows.Forms.ToolStripLabel();
            lblDatetimeShow = new System.Windows.Forms.ToolStripLabel();
            btnUnSelectAll = new System.Windows.Forms.Button();
            timer1 = new System.Windows.Forms.Timer(components);
            ((System.ComponentModel.ISupportInitialize)pbStuImage).BeginInit();
            kk.SuspendLayout();
            SuspendLayout();
            // 
            // label3
            // 
            label3.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label3.Location = new System.Drawing.Point(433, 317);
            label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            label3.Name = "label3";
            label3.Size = new System.Drawing.Size(151, 43);
            label3.TabIndex = 19;
            label3.Text = "ประเภทนักเรียน";
            // 
            // rdoStuFund
            // 
            rdoStuFund.AutoSize = true;
            rdoStuFund.Location = new System.Drawing.Point(576, 360);
            rdoStuFund.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            rdoStuFund.Name = "rdoStuFund";
            rdoStuFund.Size = new System.Drawing.Size(86, 29);
            rdoStuFund.TabIndex = 18;
            rdoStuFund.Text = "กองทุน";
            rdoStuFund.UseVisualStyleBackColor = true;
            // 
            // rdoStuNormal
            // 
            rdoStuNormal.AutoSize = true;
            rdoStuNormal.Checked = true;
            rdoStuNormal.Location = new System.Drawing.Point(433, 360);
            rdoStuNormal.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            rdoStuNormal.Name = "rdoStuNormal";
            rdoStuNormal.Size = new System.Drawing.Size(67, 29);
            rdoStuNormal.TabIndex = 17;
            rdoStuNormal.TabStop = true;
            rdoStuNormal.Text = "ปกติ";
            rdoStuNormal.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label2.Location = new System.Drawing.Point(116, 520);
            label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(169, 25);
            label2.TabIndex = 16;
            label2.Text = "รายวิชาที่ลงทะเบียน";
            // 
            // lsbStuSubject
            // 
            lsbStuSubject.FormattingEnabled = true;
            lsbStuSubject.ItemHeight = 25;
            lsbStuSubject.Location = new System.Drawing.Point(116, 555);
            lsbStuSubject.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            lsbStuSubject.Name = "lsbStuSubject";
            lsbStuSubject.Size = new System.Drawing.Size(230, 229);
            lsbStuSubject.TabIndex = 15;
            // 
            // label1
            // 
            label1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label1.Location = new System.Drawing.Point(113, 418);
            label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(123, 32);
            label1.TabIndex = 14;
            label1.Text = "ระดับชั้น";
            // 
            // pbStuImage
            // 
            pbStuImage.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            pbStuImage.Location = new System.Drawing.Point(807, 152);
            pbStuImage.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            pbStuImage.Name = "pbStuImage";
            pbStuImage.Size = new System.Drawing.Size(223, 342);
            pbStuImage.TabIndex = 13;
            pbStuImage.TabStop = false;
            // 
            // mcdRegisterDate
            // 
            mcdRegisterDate.Location = new System.Drawing.Point(113, 132);
            mcdRegisterDate.Margin = new System.Windows.Forms.Padding(13, 15, 13, 15);
            mcdRegisterDate.Name = "mcdRegisterDate";
            mcdRegisterDate.TabIndex = 12;
            // 
            // cbbStuLevel
            // 
            cbbStuLevel.FormattingEnabled = true;
            cbbStuLevel.Location = new System.Drawing.Point(111, 457);
            cbbStuLevel.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            cbbStuLevel.Name = "cbbStuLevel";
            cbbStuLevel.Size = new System.Drawing.Size(253, 33);
            cbbStuLevel.TabIndex = 11;
            // 
            // tbStuName
            // 
            tbStuName.Location = new System.Drawing.Point(433, 278);
            tbStuName.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            tbStuName.Name = "tbStuName";
            tbStuName.Size = new System.Drawing.Size(268, 31);
            tbStuName.TabIndex = 25;
            // 
            // label4
            // 
            label4.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label4.Location = new System.Drawing.Point(404, 233);
            label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            label4.Name = "label4";
            label4.Size = new System.Drawing.Size(129, 30);
            label4.TabIndex = 24;
            label4.Text = "ชื่อ-นามสกุล";
            label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tbStuID
            // 
            tbStuID.Location = new System.Drawing.Point(433, 175);
            tbStuID.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            tbStuID.Name = "tbStuID";
            tbStuID.Size = new System.Drawing.Size(268, 31);
            tbStuID.TabIndex = 27;
            // 
            // label5
            // 
            label5.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label5.Location = new System.Drawing.Point(416, 110);
            label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            label5.Name = "label5";
            label5.Size = new System.Drawing.Size(174, 65);
            label5.TabIndex = 26;
            label5.Text = "เลขประจำตัวนักเรียน";
            label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // btnMainMenu
            // 
            btnMainMenu.Image = Properties.Resources.pevious1;
            btnMainMenu.Location = new System.Drawing.Point(870, 28);
            btnMainMenu.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            btnMainMenu.Name = "btnMainMenu";
            btnMainMenu.Size = new System.Drawing.Size(146, 100);
            btnMainMenu.TabIndex = 29;
            btnMainMenu.Text = "หน้าจอหลัก";
            btnMainMenu.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            btnMainMenu.UseVisualStyleBackColor = true;
            btnMainMenu.Click += btnMainMenu_Click;
            // 
            // label6
            // 
            label6.BackColor = System.Drawing.Color.Yellow;
            label6.Font = new System.Drawing.Font("Segoe UI", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label6.ForeColor = System.Drawing.Color.Blue;
            label6.Location = new System.Drawing.Point(116, 28);
            label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            label6.Name = "label6";
            label6.Size = new System.Drawing.Size(707, 82);
            label6.TabIndex = 28;
            label6.Text = "ลงทะเบียนเรียน";
            label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            label6.UseCompatibleTextRendering = true;
            // 
            // btnSelectStuImage
            // 
            btnSelectStuImage.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            btnSelectStuImage.Location = new System.Drawing.Point(1040, 453);
            btnSelectStuImage.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            btnSelectStuImage.Name = "btnSelectStuImage";
            btnSelectStuImage.Size = new System.Drawing.Size(47, 38);
            btnSelectStuImage.TabIndex = 30;
            btnSelectStuImage.Text = "...";
            btnSelectStuImage.UseVisualStyleBackColor = true;
            // 
            // btnSelectOne
            // 
            btnSelectOne.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            btnSelectOne.ForeColor = System.Drawing.Color.Green;
            btnSelectOne.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            btnSelectOne.Location = new System.Drawing.Point(379, 558);
            btnSelectOne.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            btnSelectOne.Name = "btnSelectOne";
            btnSelectOne.Size = new System.Drawing.Size(141, 55);
            btnSelectOne.TabIndex = 31;
            btnSelectOne.Text = ">";
            btnSelectOne.UseVisualStyleBackColor = true;
            // 
            // btnSelectAll
            // 
            btnSelectAll.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            btnSelectAll.ForeColor = System.Drawing.Color.Green;
            btnSelectAll.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            btnSelectAll.Location = new System.Drawing.Point(379, 620);
            btnSelectAll.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            btnSelectAll.Name = "btnSelectAll";
            btnSelectAll.Size = new System.Drawing.Size(141, 50);
            btnSelectAll.TabIndex = 34;
            btnSelectAll.Text = ">>";
            btnSelectAll.UseVisualStyleBackColor = true;
            // 
            // btnUnSelectOne
            // 
            btnUnSelectOne.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            btnUnSelectOne.ForeColor = System.Drawing.Color.Red;
            btnUnSelectOne.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            btnUnSelectOne.Location = new System.Drawing.Point(379, 678);
            btnUnSelectOne.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            btnUnSelectOne.Name = "btnUnSelectOne";
            btnUnSelectOne.Size = new System.Drawing.Size(141, 48);
            btnUnSelectOne.TabIndex = 35;
            btnUnSelectOne.Text = "<";
            btnUnSelectOne.UseVisualStyleBackColor = true;
            // 
            // lsbStuSelectSubject
            // 
            lsbStuSelectSubject.FormattingEnabled = true;
            lsbStuSelectSubject.ItemHeight = 25;
            lsbStuSelectSubject.Location = new System.Drawing.Point(544, 555);
            lsbStuSelectSubject.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            lsbStuSelectSubject.Name = "lsbStuSelectSubject";
            lsbStuSelectSubject.Size = new System.Drawing.Size(230, 229);
            lsbStuSelectSubject.TabIndex = 36;
            // 
            // btnEnd
            // 
            btnEnd.Image = Properties.Resources.exit3;
            btnEnd.Location = new System.Drawing.Point(786, 720);
            btnEnd.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            btnEnd.Name = "btnEnd";
            btnEnd.Size = new System.Drawing.Size(309, 58);
            btnEnd.TabIndex = 39;
            btnEnd.Text = "จบโปรแกรม";
            btnEnd.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            btnEnd.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            btnEnd.UseVisualStyleBackColor = true;
            // 
            // btnRegister
            // 
            btnRegister.Image = Properties.Resources.add;
            btnRegister.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            btnRegister.Location = new System.Drawing.Point(953, 573);
            btnRegister.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            btnRegister.Name = "btnRegister";
            btnRegister.Size = new System.Drawing.Size(141, 58);
            btnRegister.TabIndex = 37;
            btnRegister.Text = "ลงทะเบียน";
            btnRegister.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            btnRegister.UseVisualStyleBackColor = true;
            // 
            // btnCancel
            // 
            btnCancel.Image = Properties.Resources.cancel1;
            btnCancel.Location = new System.Drawing.Point(786, 652);
            btnCancel.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new System.Drawing.Size(309, 58);
            btnCancel.TabIndex = 40;
            btnCancel.Text = "ยกเลิก";
            btnCancel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            btnCancel.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            btnCancel.UseVisualStyleBackColor = true;
            // 
            // chkConfirm
            // 
            chkConfirm.AutoSize = true;
            chkConfirm.Location = new System.Drawing.Point(786, 590);
            chkConfirm.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            chkConfirm.Name = "chkConfirm";
            chkConfirm.Size = new System.Drawing.Size(173, 29);
            chkConfirm.TabIndex = 41;
            chkConfirm.Text = "ยืนยันการลงทะเบียน";
            chkConfirm.UseVisualStyleBackColor = true;
            // 
            // kk
            // 
            kk.Dock = System.Windows.Forms.DockStyle.Bottom;
            kk.ImageScalingSize = new System.Drawing.Size(24, 24);
            kk.Items.AddRange(new System.Windows.Forms.ToolStripItem[] { lblNameShow, lblDatetimeShow });
            kk.Location = new System.Drawing.Point(0, 835);
            kk.Name = "kk";
            kk.Padding = new System.Windows.Forms.Padding(0, 0, 3, 0);
            kk.Size = new System.Drawing.Size(1143, 30);
            kk.TabIndex = 50;
            kk.Text = "toolStrip1";
            // 
            // lblNameShow
            // 
            lblNameShow.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            lblNameShow.ForeColor = System.Drawing.Color.Blue;
            lblNameShow.Name = "lblNameShow";
            lblNameShow.Size = new System.Drawing.Size(70, 25);
            lblNameShow.Text = "Name?";
            // 
            // lblDatetimeShow
            // 
            lblDatetimeShow.Name = "lblDatetimeShow";
            lblDatetimeShow.Size = new System.Drawing.Size(90, 25);
            lblDatetimeShow.Text = "datetime?";
            // 
            // btnUnSelectAll
            // 
            btnUnSelectAll.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            btnUnSelectAll.ForeColor = System.Drawing.Color.Red;
            btnUnSelectAll.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            btnUnSelectAll.Location = new System.Drawing.Point(379, 737);
            btnUnSelectAll.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            btnUnSelectAll.Name = "btnUnSelectAll";
            btnUnSelectAll.Size = new System.Drawing.Size(141, 48);
            btnUnSelectAll.TabIndex = 51;
            btnUnSelectAll.Text = "<<";
            btnUnSelectAll.UseVisualStyleBackColor = true;
            // 
            // timer1
            // 
            timer1.Tick += timer1_Tick;
            // 
            // FrmRegister
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            ClientSize = new System.Drawing.Size(1143, 865);
            Controls.Add(btnUnSelectAll);
            Controls.Add(kk);
            Controls.Add(chkConfirm);
            Controls.Add(btnCancel);
            Controls.Add(btnEnd);
            Controls.Add(btnRegister);
            Controls.Add(lsbStuSelectSubject);
            Controls.Add(btnUnSelectOne);
            Controls.Add(btnSelectAll);
            Controls.Add(btnSelectOne);
            Controls.Add(btnSelectStuImage);
            Controls.Add(btnMainMenu);
            Controls.Add(label6);
            Controls.Add(tbStuID);
            Controls.Add(label5);
            Controls.Add(tbStuName);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(rdoStuFund);
            Controls.Add(rdoStuNormal);
            Controls.Add(label2);
            Controls.Add(lsbStuSubject);
            Controls.Add(label1);
            Controls.Add(pbStuImage);
            Controls.Add(mcdRegisterDate);
            Controls.Add(cbbStuLevel);
            Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            Name = "FrmRegister";
            Text = "FrmRegister";
            ((System.ComponentModel.ISupportInitialize)pbStuImage).EndInit();
            kk.ResumeLayout(false);
            kk.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.RadioButton rdoStuFund;
        private System.Windows.Forms.RadioButton rdoStuNormal;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ListBox lsbStuSubject;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pbStuImage;
        private System.Windows.Forms.MonthCalendar mcdRegisterDate;
        private System.Windows.Forms.ComboBox cbbStuLevel;
        private System.Windows.Forms.TextBox tbStuName;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tbStuID;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnMainMenu;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnSelectStuImage;
        private System.Windows.Forms.Button btnSelectOne;
        private System.Windows.Forms.Button btnSelectAll;
        private System.Windows.Forms.Button btnUnSelectOne;
        private System.Windows.Forms.ListBox lsbStuSelectSubject;
        private System.Windows.Forms.Button btnEnd;
        private System.Windows.Forms.Button btnRegister;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.CheckBox chkConfirm;
        private System.Windows.Forms.ToolStrip kk;
        private System.Windows.Forms.ToolStripLabel lblNameShow;
        private System.Windows.Forms.ToolStripLabel lblDatetimeShow;
        private System.Windows.Forms.Button btnUnSelectAll;
        private System.Windows.Forms.Timer timer1;
    }
}