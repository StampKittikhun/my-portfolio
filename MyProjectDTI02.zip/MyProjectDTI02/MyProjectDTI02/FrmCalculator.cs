﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyProjectDTI02
{
    public partial class FrmCalculator : Form
    {
        public FrmCalculator()
        {
            InitializeComponent();
            //nameshow มาแสดงที่ label lblnameshow
            lblNameShow.Text = ShareDate.name_show;

            //สั่ง time ให้ Start
            timer1.Start();

            cbbPoint.SelectedIndex = 0;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FrmMainMenu frmMainMenu = new FrmMainMenu();
            frmMainMenu.Show();
            this.Hide();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            //show time date realtime
            CultureInfo culture = new CultureInfo("th-TH");
            lblDatetimeShow.Text = DateTime.Now.ToString("วันที่" + "dd เดือน MMMM พ.ศ. yyyy HH:mm:ss" + "  น.", culture);
        }

        private void tbUsername_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar)&& !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }    
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void comboBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (tbNum1.Text.Length == 0)
            {
                ShareDate.showWarningMSG("ป้อนตัวเลขตัวที่ 1 ด้วย...");
            } 
            else if (tbNum2.Text.Length == 0)
            {
                ShareDate.showWarningMSG("ป้อนตัวเลขตัวที่ 2 ด้วย...");
            }
            else
            {
                double num1 = double.Parse(tbNum1.Text);
                double num2 = double.Parse(tbNum2.Text);
                double result = num1 + num2;

                if (cbbPoint.SelectedIndex == 0)
                {
                    lblShowResultIndex.Text = result.ToString("#,##0.00");
                }
                else if (cbbPoint.SelectedIndex == 1)
                {
                    lblShowResultIndex.Text = result.ToString("#,##0.0000");
                }
                else
                {
                    lblShowResultIndex.Text = result.ToString("#,##0.00000000");
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (tbNum1.Text.Length == 0)
            {
                ShareDate.showWarningMSG("ป้อนตัวเลขตัวที่ 1 ด้วย...");
            }
            else if (tbNum2.Text.Length == 0)
            {
                ShareDate.showWarningMSG("ป้อนตัวเลขตัวที่ 2 ด้วย...");
            }
            else
            {
                double num1 = double.Parse(tbNum1.Text);
                double num2 = double.Parse(tbNum2.Text);
                double result = num1 - num2;

                if (cbbPoint.SelectedIndex == 0)
                {
                    lblShowResultIndex.Text = result.ToString("#,##0.00");
                }
                else if (cbbPoint.SelectedIndex == 1)
                {
                    lblShowResultIndex.Text = result.ToString("#,##0.0000");
                }
                else
                {
                    lblShowResultIndex.Text = result.ToString("#,##0.00000000");
                }
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (tbNum1.Text.Length == 0)
            {
                ShareDate.showWarningMSG("ป้อนตัวเลขตัวที่ 1 ด้วย...");
            }
            else if (tbNum2.Text.Length == 0)
            {
                ShareDate.showWarningMSG("ป้อนตัวเลขตัวที่ 2 ด้วย...");
            }
            else
            {
                double num1 = double.Parse(tbNum1.Text);
                double num2 = double.Parse(tbNum2.Text);
                double result = num1 * num2;

                if (cbbPoint.SelectedIndex == 0)
                {
                    lblShowResultIndex.Text = result.ToString("#,##0.00");
                }
                else if (cbbPoint.SelectedIndex == 1)
                {
                    lblShowResultIndex.Text = result.ToString("#,##0.0000");
                }
                else
                {
                    lblShowResultIndex.Text = result.ToString("#,##0.00000000");
                }
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (tbNum1.Text.Length == 0)
            {
                ShareDate.showWarningMSG("ป้อนตัวเลขตัวที่ 1 ด้วย...");
            }
            else if (tbNum2.Text.Length == 0)
            {
                ShareDate.showWarningMSG("ป้อนตัวเลขตัวที่ 2 ด้วย...");
            }
            else
            {
                double num1 = double.Parse(tbNum1.Text);
                double num2 = double.Parse(tbNum2.Text);
                double result = num1 / num2;

                if (cbbPoint.SelectedIndex == 0)
                {
                    lblShowResultIndex.Text = result.ToString("#,##0.00");
                }
                else if (cbbPoint.SelectedIndex == 1)
                {
                    lblShowResultIndex.Text = result.ToString("#,##0.0000");
                }
                else
                {
                    lblShowResultIndex.Text = result.ToString("#,##0.00000000");
                }
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (tbNum1.Text.Length == 0)
            {
                ShareDate.showWarningMSG("ป้อนตัวเลขตัวที่ 1 ด้วย...");
            }
            else if (tbNum2.Text.Length == 0)
            {
                ShareDate.showWarningMSG("ป้อนตัวเลขตัวที่ 2 ด้วย...");
            }
            else
            {
                double num1 = double.Parse(tbNum1.Text);
                double num2 = double.Parse(tbNum2.Text);
                double result =  Math.Pow(num1, num2);

                if (cbbPoint.SelectedIndex == 0)
                {
                    lblShowResultIndex.Text = result.ToString("#,##0.00");
                }
                else if (cbbPoint.SelectedIndex == 1)
                {
                    lblShowResultIndex.Text = result.ToString("#,##0.0000");
                }
                else
                {
                    lblShowResultIndex.Text = result.ToString("#,##0.00000000");
                }
            }
        }
    }
}
