﻿
namespace MyProjectDTI02
{
    partial class FrmCalculator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            button1 = new System.Windows.Forms.Button();
            label1 = new System.Windows.Forms.Label();
            tbNum1 = new System.Windows.Forms.TextBox();
            label2 = new System.Windows.Forms.Label();
            tbNum2 = new System.Windows.Forms.TextBox();
            label3 = new System.Windows.Forms.Label();
            btPlus_Click = new System.Windows.Forms.Button();
            button3 = new System.Windows.Forms.Button();
            button4 = new System.Windows.Forms.Button();
            button5 = new System.Windows.Forms.Button();
            button6 = new System.Windows.Forms.Button();
            lblShowResultIndex = new System.Windows.Forms.Label();
            label5 = new System.Windows.Forms.Label();
            cbbPoint = new System.Windows.Forms.ComboBox();
            kk = new System.Windows.Forms.ToolStrip();
            lblNameShow = new System.Windows.Forms.ToolStripLabel();
            lblDatetimeShow = new System.Windows.Forms.ToolStripLabel();
            timer1 = new System.Windows.Forms.Timer(components);
            kk.SuspendLayout();
            SuspendLayout();
            // 
            // button1
            // 
            button1.Image = Properties.Resources.pevious1;
            button1.Location = new System.Drawing.Point(833, 65);
            button1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            button1.Name = "button1";
            button1.Size = new System.Drawing.Size(146, 100);
            button1.TabIndex = 13;
            button1.Text = "หน้าจอหลัก";
            button1.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // label1
            // 
            label1.BackColor = System.Drawing.Color.Yellow;
            label1.Font = new System.Drawing.Font("Segoe UI", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label1.ForeColor = System.Drawing.Color.Blue;
            label1.Location = new System.Drawing.Point(230, 65);
            label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(570, 100);
            label1.TabIndex = 12;
            label1.Text = "Calculator";
            label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            label1.UseCompatibleTextRendering = true;
            // 
            // tbNum1
            // 
            tbNum1.Location = new System.Drawing.Point(401, 233);
            tbNum1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            tbNum1.Name = "tbNum1";
            tbNum1.PlaceholderText = "ตัวเลขเท่านั้น";
            tbNum1.Size = new System.Drawing.Size(327, 31);
            tbNum1.TabIndex = 15;
            tbNum1.KeyPress += tbUsername_KeyPress;
            // 
            // label2
            // 
            label2.Location = new System.Drawing.Point(281, 218);
            label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(129, 65);
            label2.TabIndex = 14;
            label2.Text = "ป้อนตัวเลข";
            label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tbNum2
            // 
            tbNum2.Location = new System.Drawing.Point(401, 310);
            tbNum2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            tbNum2.Name = "tbNum2";
            tbNum2.PlaceholderText = "ตัวเลขเท่านั้น";
            tbNum2.Size = new System.Drawing.Size(327, 31);
            tbNum2.TabIndex = 17;
            tbNum2.KeyPress += textBox1_KeyPress;
            // 
            // label3
            // 
            label3.Location = new System.Drawing.Point(286, 295);
            label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            label3.Name = "label3";
            label3.Size = new System.Drawing.Size(129, 65);
            label3.TabIndex = 16;
            label3.Text = "ป้อนตัวเลข";
            label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btPlus_Click
            // 
            btPlus_Click.Font = new System.Drawing.Font("Segoe UI", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            btPlus_Click.ForeColor = System.Drawing.Color.Blue;
            btPlus_Click.Location = new System.Drawing.Point(259, 398);
            btPlus_Click.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            btPlus_Click.Name = "btPlus_Click";
            btPlus_Click.Size = new System.Drawing.Size(93, 93);
            btPlus_Click.TabIndex = 18;
            btPlus_Click.Text = "+";
            btPlus_Click.UseVisualStyleBackColor = true;
            btPlus_Click.Click += button2_Click;
            // 
            // button3
            // 
            button3.Font = new System.Drawing.Font("Segoe UI", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button3.ForeColor = System.Drawing.Color.Blue;
            button3.Location = new System.Drawing.Point(389, 398);
            button3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            button3.Name = "button3";
            button3.Size = new System.Drawing.Size(93, 93);
            button3.TabIndex = 19;
            button3.Text = "-";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // button4
            // 
            button4.Font = new System.Drawing.Font("Segoe UI", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button4.ForeColor = System.Drawing.Color.Blue;
            button4.Location = new System.Drawing.Point(507, 398);
            button4.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            button4.Name = "button4";
            button4.Size = new System.Drawing.Size(93, 93);
            button4.TabIndex = 20;
            button4.Text = "x";
            button4.UseVisualStyleBackColor = true;
            button4.Click += button4_Click;
            // 
            // button5
            // 
            button5.Font = new System.Drawing.Font("Segoe UI", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button5.ForeColor = System.Drawing.Color.Blue;
            button5.Location = new System.Drawing.Point(637, 398);
            button5.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            button5.Name = "button5";
            button5.Size = new System.Drawing.Size(93, 93);
            button5.TabIndex = 21;
            button5.Text = "÷";
            button5.UseVisualStyleBackColor = true;
            button5.Click += button5_Click;
            // 
            // button6
            // 
            button6.Font = new System.Drawing.Font("Segoe UI", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button6.ForeColor = System.Drawing.Color.Blue;
            button6.Location = new System.Drawing.Point(759, 398);
            button6.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            button6.Name = "button6";
            button6.Size = new System.Drawing.Size(93, 93);
            button6.TabIndex = 22;
            button6.Text = "^";
            button6.UseVisualStyleBackColor = true;
            button6.Click += button6_Click;
            // 
            // lblShowResultIndex
            // 
            lblShowResultIndex.BackColor = System.Drawing.Color.Yellow;
            lblShowResultIndex.Font = new System.Drawing.Font("Segoe UI", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            lblShowResultIndex.ForeColor = System.Drawing.Color.Red;
            lblShowResultIndex.Location = new System.Drawing.Point(389, 607);
            lblShowResultIndex.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            lblShowResultIndex.Name = "lblShowResultIndex";
            lblShowResultIndex.Size = new System.Drawing.Size(411, 68);
            lblShowResultIndex.TabIndex = 23;
            lblShowResultIndex.Text = "?????";
            lblShowResultIndex.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            lblShowResultIndex.UseCompatibleTextRendering = true;
            // 
            // label5
            // 
            label5.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label5.Location = new System.Drawing.Point(230, 607);
            label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            label5.Name = "label5";
            label5.Size = new System.Drawing.Size(129, 65);
            label5.TabIndex = 24;
            label5.Text = "ผลลัพธ์";
            label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cbbPoint
            // 
            cbbPoint.FormattingEnabled = true;
            cbbPoint.Items.AddRange(new object[] { "ทศนิยม 2 ตำแหน่ง", "ทศนิยม 4 ตำแหน่ง", "ทศนิยม 8 ตำแหน่ง" });
            cbbPoint.Location = new System.Drawing.Point(401, 535);
            cbbPoint.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            cbbPoint.Name = "cbbPoint";
            cbbPoint.Size = new System.Drawing.Size(327, 33);
            cbbPoint.TabIndex = 25;
            cbbPoint.KeyPress += comboBox1_KeyPress;
            // 
            // kk
            // 
            kk.Dock = System.Windows.Forms.DockStyle.Bottom;
            kk.ImageScalingSize = new System.Drawing.Size(24, 24);
            kk.Items.AddRange(new System.Windows.Forms.ToolStripItem[] { lblNameShow, lblDatetimeShow });
            kk.Location = new System.Drawing.Point(0, 720);
            kk.Name = "kk";
            kk.Padding = new System.Windows.Forms.Padding(0, 0, 3, 0);
            kk.Size = new System.Drawing.Size(1143, 30);
            kk.TabIndex = 51;
            kk.Text = "toolStrip1";
            // 
            // lblNameShow
            // 
            lblNameShow.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            lblNameShow.ForeColor = System.Drawing.Color.Blue;
            lblNameShow.Name = "lblNameShow";
            lblNameShow.Size = new System.Drawing.Size(70, 25);
            lblNameShow.Text = "Name?";
            // 
            // lblDatetimeShow
            // 
            lblDatetimeShow.Name = "lblDatetimeShow";
            lblDatetimeShow.Size = new System.Drawing.Size(90, 25);
            lblDatetimeShow.Text = "datetime?";
            // 
            // timer1
            // 
            timer1.Tick += timer1_Tick;
            // 
            // FrmCalculator
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            ClientSize = new System.Drawing.Size(1143, 750);
            Controls.Add(kk);
            Controls.Add(cbbPoint);
            Controls.Add(label5);
            Controls.Add(lblShowResultIndex);
            Controls.Add(button6);
            Controls.Add(button5);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(btPlus_Click);
            Controls.Add(tbNum2);
            Controls.Add(label3);
            Controls.Add(tbNum1);
            Controls.Add(label2);
            Controls.Add(button1);
            Controls.Add(label1);
            Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            Name = "FrmCalculator";
            Text = "FrmCalculator";
            kk.ResumeLayout(false);
            kk.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbNum1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tbNum2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btPlus_Click;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Label lblShowResultIndex;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cbbPoint;
        private System.Windows.Forms.ToolStrip kk;
        private System.Windows.Forms.ToolStripLabel lblNameShow;
        private System.Windows.Forms.ToolStripLabel lblDatetimeShow;
        private System.Windows.Forms.Timer timer1;
    }
}