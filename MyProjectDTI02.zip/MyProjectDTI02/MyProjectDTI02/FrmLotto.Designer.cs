﻿
namespace MyProjectDTI02
{
    partial class FrmLotto
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            btnMainMenu = new System.Windows.Forms.Button();
            label1 = new System.Windows.Forms.Label();
            dtpLottoDate = new System.Windows.Forms.DateTimePicker();
            label3 = new System.Windows.Forms.Label();
            groupBox1 = new System.Windows.Forms.GroupBox();
            btnLotto1 = new System.Windows.Forms.Button();
            lblLotto1 = new System.Windows.Forms.Label();
            groupBox2 = new System.Windows.Forms.GroupBox();
            rdoCloseLotto = new System.Windows.Forms.RadioButton();
            rdoOpenLotto = new System.Windows.Forms.RadioButton();
            btnLotto2Down = new System.Windows.Forms.Button();
            lblLotto2Down = new System.Windows.Forms.Label();
            kk = new System.Windows.Forms.ToolStrip();
            lblNameShow = new System.Windows.Forms.ToolStripLabel();
            lblDatetimeShow = new System.Windows.Forms.ToolStripLabel();
            groupBox3 = new System.Windows.Forms.GroupBox();
            lblLotto3On2 = new System.Windows.Forms.Label();
            btnLotto3on = new System.Windows.Forms.Button();
            lblLotto3On1 = new System.Windows.Forms.Label();
            groupBox4 = new System.Windows.Forms.GroupBox();
            lblLotto3Down2 = new System.Windows.Forms.Label();
            btnLotto3Down = new System.Windows.Forms.Button();
            lblLotto3Down1 = new System.Windows.Forms.Label();
            timer1 = new System.Windows.Forms.Timer(components);
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            kk.SuspendLayout();
            groupBox3.SuspendLayout();
            groupBox4.SuspendLayout();
            SuspendLayout();
            // 
            // btnMainMenu
            // 
            btnMainMenu.Image = Properties.Resources.pevious1;
            btnMainMenu.Location = new System.Drawing.Point(891, 77);
            btnMainMenu.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            btnMainMenu.Name = "btnMainMenu";
            btnMainMenu.Size = new System.Drawing.Size(146, 100);
            btnMainMenu.TabIndex = 17;
            btnMainMenu.Text = "หน้าจอหลัก";
            btnMainMenu.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            btnMainMenu.UseVisualStyleBackColor = true;
            btnMainMenu.Click += btnMainMenu_Click;
            // 
            // label1
            // 
            label1.BackColor = System.Drawing.Color.Yellow;
            label1.Font = new System.Drawing.Font("Segoe UI", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label1.ForeColor = System.Drawing.Color.Blue;
            label1.Location = new System.Drawing.Point(137, 77);
            label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(707, 82);
            label1.TabIndex = 16;
            label1.Text = "LOTTO หวยออนไลน์";
            label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            label1.UseCompatibleTextRendering = true;
            // 
            // dtpLottoDate
            // 
            dtpLottoDate.Location = new System.Drawing.Point(410, 202);
            dtpLottoDate.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            dtpLottoDate.Name = "dtpLottoDate";
            dtpLottoDate.Size = new System.Drawing.Size(327, 31);
            dtpLottoDate.TabIndex = 19;
            dtpLottoDate.Value = new System.DateTime(2024, 6, 16, 15, 12, 19, 0);
            // 
            // label3
            // 
            label3.Location = new System.Drawing.Point(266, 192);
            label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            label3.Name = "label3";
            label3.Size = new System.Drawing.Size(129, 65);
            label3.TabIndex = 18;
            label3.Text = "งวดประจำวันที่";
            label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(btnLotto1);
            groupBox1.Controls.Add(lblLotto1);
            groupBox1.Location = new System.Drawing.Point(210, 278);
            groupBox1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            groupBox1.Name = "groupBox1";
            groupBox1.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            groupBox1.Size = new System.Drawing.Size(634, 113);
            groupBox1.TabIndex = 20;
            groupBox1.TabStop = false;
            groupBox1.Text = "รางวัลที่ 1 ";
            // 
            // btnLotto1
            // 
            btnLotto1.Enabled = false;
            btnLotto1.Image = Properties.Resources.start2;
            btnLotto1.Location = new System.Drawing.Point(430, 22);
            btnLotto1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            btnLotto1.Name = "btnLotto1";
            btnLotto1.Size = new System.Drawing.Size(99, 83);
            btnLotto1.TabIndex = 1;
            btnLotto1.UseVisualStyleBackColor = true;
            btnLotto1.Click += btnLotto1_Click;
            // 
            // lblLotto1
            // 
            lblLotto1.Font = new System.Drawing.Font("Segoe UI", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            lblLotto1.ForeColor = System.Drawing.Color.Red;
            lblLotto1.Location = new System.Drawing.Point(130, 22);
            lblLotto1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            lblLotto1.Name = "lblLotto1";
            lblLotto1.Size = new System.Drawing.Size(220, 87);
            lblLotto1.TabIndex = 0;
            lblLotto1.Text = "??????";
            lblLotto1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(rdoCloseLotto);
            groupBox2.Controls.Add(rdoOpenLotto);
            groupBox2.Controls.Add(btnLotto2Down);
            groupBox2.Controls.Add(lblLotto2Down);
            groupBox2.Location = new System.Drawing.Point(207, 643);
            groupBox2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            groupBox2.Name = "groupBox2";
            groupBox2.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            groupBox2.Size = new System.Drawing.Size(634, 147);
            groupBox2.TabIndex = 21;
            groupBox2.TabStop = false;
            groupBox2.Text = "รางวัลเลข 2 ตัวท้าย";
            // 
            // rdoCloseLotto
            // 
            rdoCloseLotto.AutoSize = true;
            rdoCloseLotto.Location = new System.Drawing.Point(430, 30);
            rdoCloseLotto.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            rdoCloseLotto.Name = "rdoCloseLotto";
            rdoCloseLotto.Size = new System.Drawing.Size(159, 29);
            rdoCloseLotto.TabIndex = 50;
            rdoCloseLotto.Text = "เปิดการออกรางวัล";
            rdoCloseLotto.UseVisualStyleBackColor = true;
            rdoCloseLotto.Click += rdoCloseLotto_Click;
            // 
            // rdoOpenLotto
            // 
            rdoOpenLotto.AutoSize = true;
            rdoOpenLotto.Checked = true;
            rdoOpenLotto.Location = new System.Drawing.Point(430, 92);
            rdoOpenLotto.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            rdoOpenLotto.Name = "rdoOpenLotto";
            rdoOpenLotto.Size = new System.Drawing.Size(154, 29);
            rdoOpenLotto.TabIndex = 49;
            rdoOpenLotto.TabStop = true;
            rdoOpenLotto.Text = "ปิดการออกรางวัล";
            rdoOpenLotto.UseVisualStyleBackColor = true;
            rdoOpenLotto.Click += rdoOpenLotto_Click;
            // 
            // btnLotto2Down
            // 
            btnLotto2Down.Enabled = false;
            btnLotto2Down.Image = Properties.Resources.start2;
            btnLotto2Down.Location = new System.Drawing.Point(301, 38);
            btnLotto2Down.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            btnLotto2Down.Name = "btnLotto2Down";
            btnLotto2Down.Size = new System.Drawing.Size(99, 83);
            btnLotto2Down.TabIndex = 1;
            btnLotto2Down.UseVisualStyleBackColor = true;
            btnLotto2Down.Click += btnLotto2Down_Click;
            // 
            // lblLotto2Down
            // 
            lblLotto2Down.Font = new System.Drawing.Font("Segoe UI", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            lblLotto2Down.ForeColor = System.Drawing.Color.Red;
            lblLotto2Down.Location = new System.Drawing.Point(149, 32);
            lblLotto2Down.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            lblLotto2Down.Name = "lblLotto2Down";
            lblLotto2Down.Size = new System.Drawing.Size(150, 87);
            lblLotto2Down.TabIndex = 0;
            lblLotto2Down.Text = "??";
            lblLotto2Down.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // kk
            // 
            kk.Dock = System.Windows.Forms.DockStyle.Bottom;
            kk.ImageScalingSize = new System.Drawing.Size(24, 24);
            kk.Items.AddRange(new System.Windows.Forms.ToolStripItem[] { lblNameShow, lblDatetimeShow });
            kk.Location = new System.Drawing.Point(0, 810);
            kk.Name = "kk";
            kk.Padding = new System.Windows.Forms.Padding(0, 0, 3, 0);
            kk.Size = new System.Drawing.Size(1143, 30);
            kk.TabIndex = 48;
            kk.Text = "toolStrip1";
            // 
            // lblNameShow
            // 
            lblNameShow.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            lblNameShow.ForeColor = System.Drawing.Color.Blue;
            lblNameShow.Name = "lblNameShow";
            lblNameShow.Size = new System.Drawing.Size(70, 25);
            lblNameShow.Text = "Name?";
            // 
            // lblDatetimeShow
            // 
            lblDatetimeShow.Name = "lblDatetimeShow";
            lblDatetimeShow.Size = new System.Drawing.Size(90, 25);
            lblDatetimeShow.Text = "datetime?";
            // 
            // groupBox3
            // 
            groupBox3.Controls.Add(lblLotto3On2);
            groupBox3.Controls.Add(btnLotto3on);
            groupBox3.Controls.Add(lblLotto3On1);
            groupBox3.Location = new System.Drawing.Point(206, 402);
            groupBox3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            groupBox3.Name = "groupBox3";
            groupBox3.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            groupBox3.Size = new System.Drawing.Size(320, 238);
            groupBox3.TabIndex = 49;
            groupBox3.TabStop = false;
            groupBox3.Text = "รางวัล 3 ตัวบน";
            // 
            // lblLotto3On2
            // 
            lblLotto3On2.Font = new System.Drawing.Font("Segoe UI", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            lblLotto3On2.ForeColor = System.Drawing.Color.Red;
            lblLotto3On2.Location = new System.Drawing.Point(39, 120);
            lblLotto3On2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            lblLotto3On2.Name = "lblLotto3On2";
            lblLotto3On2.Size = new System.Drawing.Size(150, 87);
            lblLotto3On2.TabIndex = 2;
            lblLotto3On2.Text = "???";
            lblLotto3On2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnLotto3on
            // 
            btnLotto3on.Enabled = false;
            btnLotto3on.Image = Properties.Resources.start2;
            btnLotto3on.Location = new System.Drawing.Point(197, 77);
            btnLotto3on.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            btnLotto3on.Name = "btnLotto3on";
            btnLotto3on.Size = new System.Drawing.Size(99, 83);
            btnLotto3on.TabIndex = 1;
            btnLotto3on.UseVisualStyleBackColor = true;
            btnLotto3on.Click += btnLotto3on_Click;
            // 
            // lblLotto3On1
            // 
            lblLotto3On1.Font = new System.Drawing.Font("Segoe UI", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            lblLotto3On1.ForeColor = System.Drawing.Color.Red;
            lblLotto3On1.Location = new System.Drawing.Point(43, 33);
            lblLotto3On1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            lblLotto3On1.Name = "lblLotto3On1";
            lblLotto3On1.Size = new System.Drawing.Size(150, 87);
            lblLotto3On1.TabIndex = 0;
            lblLotto3On1.Text = "???";
            lblLotto3On1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // groupBox4
            // 
            groupBox4.Controls.Add(lblLotto3Down2);
            groupBox4.Controls.Add(btnLotto3Down);
            groupBox4.Controls.Add(lblLotto3Down1);
            groupBox4.Location = new System.Drawing.Point(534, 402);
            groupBox4.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            groupBox4.Name = "groupBox4";
            groupBox4.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            groupBox4.Size = new System.Drawing.Size(310, 238);
            groupBox4.TabIndex = 50;
            groupBox4.TabStop = false;
            groupBox4.Text = "รางวัล 3 ตัวล่าง";
            // 
            // lblLotto3Down2
            // 
            lblLotto3Down2.Font = new System.Drawing.Font("Segoe UI", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            lblLotto3Down2.ForeColor = System.Drawing.Color.Red;
            lblLotto3Down2.Location = new System.Drawing.Point(39, 120);
            lblLotto3Down2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            lblLotto3Down2.Name = "lblLotto3Down2";
            lblLotto3Down2.Size = new System.Drawing.Size(150, 87);
            lblLotto3Down2.TabIndex = 2;
            lblLotto3Down2.Text = "???";
            lblLotto3Down2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnLotto3Down
            // 
            btnLotto3Down.Enabled = false;
            btnLotto3Down.Image = Properties.Resources.start2;
            btnLotto3Down.Location = new System.Drawing.Point(197, 77);
            btnLotto3Down.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            btnLotto3Down.Name = "btnLotto3Down";
            btnLotto3Down.Size = new System.Drawing.Size(99, 83);
            btnLotto3Down.TabIndex = 1;
            btnLotto3Down.UseVisualStyleBackColor = true;
            btnLotto3Down.Click += btnLotto3Down_Click;
            // 
            // lblLotto3Down1
            // 
            lblLotto3Down1.Font = new System.Drawing.Font("Segoe UI", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            lblLotto3Down1.ForeColor = System.Drawing.Color.Red;
            lblLotto3Down1.Location = new System.Drawing.Point(43, 33);
            lblLotto3Down1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            lblLotto3Down1.Name = "lblLotto3Down1";
            lblLotto3Down1.Size = new System.Drawing.Size(150, 87);
            lblLotto3Down1.TabIndex = 0;
            lblLotto3Down1.Text = "???";
            lblLotto3Down1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // timer1
            // 
            timer1.Tick += timer1_Tick;
            // 
            // FrmLotto
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            ClientSize = new System.Drawing.Size(1143, 840);
            Controls.Add(groupBox4);
            Controls.Add(groupBox3);
            Controls.Add(kk);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Controls.Add(dtpLottoDate);
            Controls.Add(label3);
            Controls.Add(btnMainMenu);
            Controls.Add(label1);
            Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            Name = "FrmLotto";
            Text = "FrmLotto";
            groupBox1.ResumeLayout(false);
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            kk.ResumeLayout(false);
            kk.PerformLayout();
            groupBox3.ResumeLayout(false);
            groupBox4.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Button btnMainMenu;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker dtpLottoDate;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnLotto1;
        private System.Windows.Forms.Label lblLotto1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btnLotto2Down;
        private System.Windows.Forms.Label lblLotto2Down;
        private System.Windows.Forms.ToolStrip kk;
        private System.Windows.Forms.ToolStripLabel lblNameShow;
        private System.Windows.Forms.ToolStripLabel lblDatetimeShow;
        private System.Windows.Forms.RadioButton rdoCloseLotto;
        private System.Windows.Forms.RadioButton rdoOpenLotto;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label lblLotto3On2;
        private System.Windows.Forms.Button btnLotto3on;
        private System.Windows.Forms.Label lblLotto3On1;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label lblLotto3Down2;
        private System.Windows.Forms.Button btnLotto3Down;
        private System.Windows.Forms.Label lblLotto3Down1;
        private System.Windows.Forms.Timer timer1;
    }
}