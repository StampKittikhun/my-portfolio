﻿
namespace MyProjectDTI02
{
    partial class FrmDooDung
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            mtbIDCard = new System.Windows.Forms.MaskedTextBox();
            nudWeight = new System.Windows.Forms.NumericUpDown();
            nudHeight = new System.Windows.Forms.NumericUpDown();
            dtpBirthDate = new System.Windows.Forms.DateTimePicker();
            label3 = new System.Windows.Forms.Label();
            tbName = new System.Windows.Forms.TextBox();
            label2 = new System.Windows.Forms.Label();
            btnMainMenu = new System.Windows.Forms.Button();
            label1 = new System.Windows.Forms.Label();
            label4 = new System.Windows.Forms.Label();
            label5 = new System.Windows.Forms.Label();
            label6 = new System.Windows.Forms.Label();
            label7 = new System.Windows.Forms.Label();
            label8 = new System.Windows.Forms.Label();
            groupBox1 = new System.Windows.Forms.GroupBox();
            groupBox2 = new System.Windows.Forms.GroupBox();
            lblShowResultDung = new System.Windows.Forms.Label();
            lblHeight = new System.Windows.Forms.Label();
            lblWeight = new System.Windows.Forms.Label();
            lblAge = new System.Windows.Forms.Label();
            lblBirthDate = new System.Windows.Forms.Label();
            lblName = new System.Windows.Forms.Label();
            lblIdCard = new System.Windows.Forms.Label();
            label14 = new System.Windows.Forms.Label();
            label9 = new System.Windows.Forms.Label();
            label12 = new System.Windows.Forms.Label();
            label10 = new System.Windows.Forms.Label();
            label13 = new System.Windows.Forms.Label();
            label11 = new System.Windows.Forms.Label();
            kk = new System.Windows.Forms.ToolStrip();
            lblNameShow = new System.Windows.Forms.ToolStripLabel();
            lblDatetimeShow = new System.Windows.Forms.ToolStripLabel();
            groupBox4 = new System.Windows.Forms.GroupBox();
            pbShowImage = new System.Windows.Forms.Button();
            btnSelectImage = new System.Windows.Forms.PictureBox();
            btnEnd = new System.Windows.Forms.Button();
            btnDooDung = new System.Windows.Forms.Button();
            btnNew = new System.Windows.Forms.Button();
            timer1 = new System.Windows.Forms.Timer(components);
            ((System.ComponentModel.ISupportInitialize)nudWeight).BeginInit();
            ((System.ComponentModel.ISupportInitialize)nudHeight).BeginInit();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            kk.SuspendLayout();
            groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)btnSelectImage).BeginInit();
            SuspendLayout();
            // 
            // mtbIDCard
            // 
            mtbIDCard.Location = new System.Drawing.Point(163, 65);
            mtbIDCard.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            mtbIDCard.Mask = "0-0000-00000-00-0";
            mtbIDCard.Name = "mtbIDCard";
            mtbIDCard.Size = new System.Drawing.Size(265, 31);
            mtbIDCard.TabIndex = 0;
            // 
            // nudWeight
            // 
            nudWeight.Location = new System.Drawing.Point(160, 243);
            nudWeight.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            nudWeight.Name = "nudWeight";
            nudWeight.Size = new System.Drawing.Size(141, 31);
            nudWeight.TabIndex = 1;
            // 
            // nudHeight
            // 
            nudHeight.Location = new System.Drawing.Point(160, 292);
            nudHeight.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            nudHeight.Name = "nudHeight";
            nudHeight.Size = new System.Drawing.Size(141, 31);
            nudHeight.TabIndex = 2;
            // 
            // dtpBirthDate
            // 
            dtpBirthDate.Location = new System.Drawing.Point(160, 182);
            dtpBirthDate.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            dtpBirthDate.Name = "dtpBirthDate";
            dtpBirthDate.Size = new System.Drawing.Size(268, 31);
            dtpBirthDate.TabIndex = 21;
            dtpBirthDate.Value = new System.DateTime(2024, 6, 16, 15, 12, 19, 0);
            // 
            // label3
            // 
            label3.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label3.Location = new System.Drawing.Point(16, 172);
            label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            label3.Name = "label3";
            label3.Size = new System.Drawing.Size(129, 65);
            label3.TabIndex = 20;
            label3.Text = "วัน-เดือน-ปีเกิด";
            label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tbName
            // 
            tbName.Location = new System.Drawing.Point(160, 123);
            tbName.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            tbName.Name = "tbName";
            tbName.Size = new System.Drawing.Size(268, 31);
            tbName.TabIndex = 23;
            // 
            // label2
            // 
            label2.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label2.Location = new System.Drawing.Point(16, 108);
            label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(129, 65);
            label2.TabIndex = 22;
            label2.Text = "ชื่อ-นามสกุล";
            label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            label2.Click += label2_Click;
            // 
            // btnMainMenu
            // 
            btnMainMenu.Image = Properties.Resources.pevious1;
            btnMainMenu.Location = new System.Drawing.Point(813, 58);
            btnMainMenu.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            btnMainMenu.Name = "btnMainMenu";
            btnMainMenu.Size = new System.Drawing.Size(146, 100);
            btnMainMenu.TabIndex = 25;
            btnMainMenu.Text = "หน้าจอหลัก";
            btnMainMenu.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            btnMainMenu.UseVisualStyleBackColor = true;
            btnMainMenu.Click += btnMainMenu_Click;
            // 
            // label1
            // 
            label1.BackColor = System.Drawing.Color.Yellow;
            label1.Font = new System.Drawing.Font("Segoe UI", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label1.ForeColor = System.Drawing.Color.Blue;
            label1.Location = new System.Drawing.Point(59, 58);
            label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(707, 82);
            label1.TabIndex = 24;
            label1.Text = "ดูดวงแม่นๆ";
            label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            label1.UseCompatibleTextRendering = true;
            // 
            // label4
            // 
            label4.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label4.Location = new System.Drawing.Point(16, 50);
            label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            label4.Name = "label4";
            label4.Size = new System.Drawing.Size(129, 65);
            label4.TabIndex = 26;
            label4.Text = "DI Card";
            label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label5
            // 
            label5.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label5.Location = new System.Drawing.Point(64, 233);
            label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            label5.Name = "label5";
            label5.Size = new System.Drawing.Size(80, 58);
            label5.TabIndex = 27;
            label5.Text = "น้ำหนัก";
            label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label6
            // 
            label6.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label6.Location = new System.Drawing.Point(64, 292);
            label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            label6.Name = "label6";
            label6.Size = new System.Drawing.Size(80, 48);
            label6.TabIndex = 28;
            label6.Text = "ส่วนสูง";
            label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label7
            // 
            label7.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label7.Location = new System.Drawing.Point(310, 288);
            label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            label7.Name = "label7";
            label7.Size = new System.Drawing.Size(80, 48);
            label7.TabIndex = 30;
            label7.Text = "เซนติเมตร";
            label7.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label8
            // 
            label8.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label8.Location = new System.Drawing.Point(310, 230);
            label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            label8.Name = "label8";
            label8.Size = new System.Drawing.Size(80, 58);
            label8.TabIndex = 29;
            label8.Text = "กิโลกรัม";
            label8.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(label7);
            groupBox1.Controls.Add(label8);
            groupBox1.Controls.Add(label6);
            groupBox1.Controls.Add(label5);
            groupBox1.Controls.Add(label4);
            groupBox1.Controls.Add(tbName);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(dtpBirthDate);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(nudHeight);
            groupBox1.Controls.Add(nudWeight);
            groupBox1.Controls.Add(mtbIDCard);
            groupBox1.Location = new System.Drawing.Point(59, 167);
            groupBox1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            groupBox1.Name = "groupBox1";
            groupBox1.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            groupBox1.Size = new System.Drawing.Size(480, 380);
            groupBox1.TabIndex = 31;
            groupBox1.TabStop = false;
            groupBox1.Text = "ข้อมูลส่วนตัว";
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(lblShowResultDung);
            groupBox2.Controls.Add(lblHeight);
            groupBox2.Controls.Add(lblWeight);
            groupBox2.Controls.Add(lblAge);
            groupBox2.Controls.Add(lblBirthDate);
            groupBox2.Controls.Add(lblName);
            groupBox2.Controls.Add(lblIdCard);
            groupBox2.Controls.Add(label14);
            groupBox2.Controls.Add(label9);
            groupBox2.Controls.Add(label12);
            groupBox2.Controls.Add(label10);
            groupBox2.Controls.Add(label13);
            groupBox2.Controls.Add(label11);
            groupBox2.Location = new System.Drawing.Point(550, 177);
            groupBox2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            groupBox2.Name = "groupBox2";
            groupBox2.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            groupBox2.Size = new System.Drawing.Size(409, 630);
            groupBox2.TabIndex = 32;
            groupBox2.TabStop = false;
            groupBox2.Text = "ผลดวงของคุณ";
            // 
            // lblShowResultDung
            // 
            lblShowResultDung.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            lblShowResultDung.ForeColor = System.Drawing.Color.FromArgb(192, 0, 192);
            lblShowResultDung.Location = new System.Drawing.Point(21, 449);
            lblShowResultDung.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            lblShowResultDung.Name = "lblShowResultDung";
            lblShowResultDung.Size = new System.Drawing.Size(380, 176);
            lblShowResultDung.TabIndex = 0;
            lblShowResultDung.Text = "ผลดวง";
            lblShowResultDung.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblHeight
            // 
            lblHeight.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            lblHeight.ForeColor = System.Drawing.Color.FromArgb(0, 64, 0);
            lblHeight.Location = new System.Drawing.Point(160, 378);
            lblHeight.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            lblHeight.Name = "lblHeight";
            lblHeight.Size = new System.Drawing.Size(218, 38);
            lblHeight.TabIndex = 42;
            lblHeight.Text = "xxxxxxxxxxxxx";
            // 
            // lblWeight
            // 
            lblWeight.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            lblWeight.ForeColor = System.Drawing.Color.FromArgb(0, 64, 0);
            lblWeight.Location = new System.Drawing.Point(160, 325);
            lblWeight.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            lblWeight.Name = "lblWeight";
            lblWeight.Size = new System.Drawing.Size(218, 38);
            lblWeight.TabIndex = 41;
            lblWeight.Text = "xxxxxxxxxxxxx";
            // 
            // lblAge
            // 
            lblAge.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            lblAge.ForeColor = System.Drawing.Color.FromArgb(0, 64, 0);
            lblAge.Location = new System.Drawing.Point(160, 255);
            lblAge.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            lblAge.Name = "lblAge";
            lblAge.Size = new System.Drawing.Size(218, 38);
            lblAge.TabIndex = 40;
            lblAge.Text = "xxxxxxxxxxxxx";
            // 
            // lblBirthDate
            // 
            lblBirthDate.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            lblBirthDate.ForeColor = System.Drawing.Color.FromArgb(0, 64, 0);
            lblBirthDate.Location = new System.Drawing.Point(116, 193);
            lblBirthDate.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            lblBirthDate.Name = "lblBirthDate";
            lblBirthDate.Size = new System.Drawing.Size(285, 38);
            lblBirthDate.TabIndex = 39;
            lblBirthDate.Text = "xxxxxxxxxxxxx";
            // 
            // lblName
            // 
            lblName.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            lblName.ForeColor = System.Drawing.Color.FromArgb(0, 64, 0);
            lblName.Location = new System.Drawing.Point(160, 130);
            lblName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            lblName.Name = "lblName";
            lblName.Size = new System.Drawing.Size(218, 38);
            lblName.TabIndex = 38;
            lblName.Text = "xxxxxxxxxxxxx";
            // 
            // lblIdCard
            // 
            lblIdCard.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            lblIdCard.ForeColor = System.Drawing.Color.FromArgb(0, 64, 0);
            lblIdCard.Location = new System.Drawing.Point(160, 75);
            lblIdCard.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            lblIdCard.Name = "lblIdCard";
            lblIdCard.Size = new System.Drawing.Size(218, 38);
            lblIdCard.TabIndex = 37;
            lblIdCard.Text = "xxxxxxxxxxxxx";
            // 
            // label14
            // 
            label14.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label14.Location = new System.Drawing.Point(21, 242);
            label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            label14.Name = "label14";
            label14.Size = new System.Drawing.Size(116, 58);
            label14.TabIndex = 36;
            label14.Text = "อายุ";
            label14.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label9
            // 
            label9.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label9.Location = new System.Drawing.Point(21, 370);
            label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            label9.Name = "label9";
            label9.Size = new System.Drawing.Size(116, 48);
            label9.TabIndex = 35;
            label9.Text = "ส่วนสูง";
            label9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label12
            // 
            label12.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label12.Location = new System.Drawing.Point(21, 113);
            label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            label12.Name = "label12";
            label12.Size = new System.Drawing.Size(116, 65);
            label12.TabIndex = 32;
            label12.Text = "ชื่อ-นามสกุล";
            label12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label10
            // 
            label10.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label10.Location = new System.Drawing.Point(21, 312);
            label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            label10.Name = "label10";
            label10.Size = new System.Drawing.Size(116, 58);
            label10.TabIndex = 34;
            label10.Text = "น้ำหนัก";
            label10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label13
            // 
            label13.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label13.Location = new System.Drawing.Point(21, 177);
            label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            label13.Name = "label13";
            label13.Size = new System.Drawing.Size(116, 65);
            label13.TabIndex = 31;
            label13.Text = "ว/ด/ป-เกิด";
            label13.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label11
            // 
            label11.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label11.Location = new System.Drawing.Point(21, 55);
            label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            label11.Name = "label11";
            label11.Size = new System.Drawing.Size(116, 65);
            label11.TabIndex = 33;
            label11.Text = "DI Card";
            label11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // kk
            // 
            kk.Dock = System.Windows.Forms.DockStyle.Bottom;
            kk.ImageScalingSize = new System.Drawing.Size(24, 24);
            kk.Items.AddRange(new System.Windows.Forms.ToolStripItem[] { lblNameShow, lblDatetimeShow });
            kk.Location = new System.Drawing.Point(0, 823);
            kk.Name = "kk";
            kk.Padding = new System.Windows.Forms.Padding(0, 0, 3, 0);
            kk.Size = new System.Drawing.Size(1007, 30);
            kk.TabIndex = 49;
            kk.Text = "toolStrip1";
            // 
            // lblNameShow
            // 
            lblNameShow.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            lblNameShow.ForeColor = System.Drawing.Color.Blue;
            lblNameShow.Name = "lblNameShow";
            lblNameShow.Size = new System.Drawing.Size(70, 25);
            lblNameShow.Text = "Name?";
            // 
            // lblDatetimeShow
            // 
            lblDatetimeShow.Name = "lblDatetimeShow";
            lblDatetimeShow.Size = new System.Drawing.Size(90, 25);
            lblDatetimeShow.Text = "datetime?";
            // 
            // groupBox4
            // 
            groupBox4.Controls.Add(pbShowImage);
            groupBox4.Controls.Add(btnSelectImage);
            groupBox4.Controls.Add(btnEnd);
            groupBox4.Controls.Add(btnDooDung);
            groupBox4.Controls.Add(btnNew);
            groupBox4.Location = new System.Drawing.Point(57, 557);
            groupBox4.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            groupBox4.Name = "groupBox4";
            groupBox4.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            groupBox4.Size = new System.Drawing.Size(480, 250);
            groupBox4.TabIndex = 50;
            groupBox4.TabStop = false;
            // 
            // pbShowImage
            // 
            pbShowImage.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            pbShowImage.Location = new System.Drawing.Point(359, 187);
            pbShowImage.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            pbShowImage.Name = "pbShowImage";
            pbShowImage.Size = new System.Drawing.Size(47, 38);
            pbShowImage.TabIndex = 4;
            pbShowImage.Text = "...";
            pbShowImage.UseVisualStyleBackColor = true;
            // 
            // btnSelectImage
            // 
            btnSelectImage.Image = Properties.Resources.marvel11;
            btnSelectImage.Location = new System.Drawing.Point(190, 35);
            btnSelectImage.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            btnSelectImage.Name = "btnSelectImage";
            btnSelectImage.Size = new System.Drawing.Size(150, 190);
            btnSelectImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            btnSelectImage.TabIndex = 3;
            btnSelectImage.TabStop = false;
            // 
            // btnEnd
            // 
            btnEnd.Image = Properties.Resources.exit3;
            btnEnd.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            btnEnd.Location = new System.Drawing.Point(20, 168);
            btnEnd.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            btnEnd.Name = "btnEnd";
            btnEnd.Size = new System.Drawing.Size(141, 58);
            btnEnd.TabIndex = 2;
            btnEnd.Text = "จบโปรแกรม";
            btnEnd.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            btnEnd.UseVisualStyleBackColor = true;
            // 
            // btnDooDung
            // 
            btnDooDung.Image = Properties.Resources.find11;
            btnDooDung.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            btnDooDung.Location = new System.Drawing.Point(20, 100);
            btnDooDung.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            btnDooDung.Name = "btnDooDung";
            btnDooDung.Size = new System.Drawing.Size(141, 58);
            btnDooDung.TabIndex = 1;
            btnDooDung.Text = "ดูดวง";
            btnDooDung.UseVisualStyleBackColor = true;
            btnDooDung.Click += btnDooDung_Click;
            // 
            // btnNew
            // 
            btnNew.Image = Properties.Resources.new1;
            btnNew.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            btnNew.Location = new System.Drawing.Point(20, 32);
            btnNew.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            btnNew.Name = "btnNew";
            btnNew.Size = new System.Drawing.Size(141, 58);
            btnNew.TabIndex = 0;
            btnNew.Text = "ใหม่";
            btnNew.UseVisualStyleBackColor = true;
            btnNew.Click += btnNew_Click;
            // 
            // timer1
            // 
            timer1.Tick += timer1_Tick;
            // 
            // FrmDooDung
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            BackColor = System.Drawing.SystemColors.ButtonFace;
            ClientSize = new System.Drawing.Size(1007, 853);
            Controls.Add(groupBox4);
            Controls.Add(kk);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Controls.Add(btnMainMenu);
            Controls.Add(label1);
            Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            Name = "FrmDooDung";
            Text = "FrmDooDung";
            ((System.ComponentModel.ISupportInitialize)nudWeight).EndInit();
            ((System.ComponentModel.ISupportInitialize)nudHeight).EndInit();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            kk.ResumeLayout(false);
            kk.PerformLayout();
            groupBox4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)btnSelectImage).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private System.Windows.Forms.MaskedTextBox mtbIDCard;
        private System.Windows.Forms.NumericUpDown nudWeight;
        private System.Windows.Forms.NumericUpDown nudHeight;
        private System.Windows.Forms.DateTimePicker dtpBirthDate;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tbName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnMainMenu;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label lblHeight;
        private System.Windows.Forms.Label lblWeight;
        private System.Windows.Forms.Label lblAge;
        private System.Windows.Forms.Label lblBirthDate;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Label lblIdCard;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ToolStrip kk;
        private System.Windows.Forms.ToolStripLabel lblNameShow;
        private System.Windows.Forms.ToolStripLabel lblDatetimeShow;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button pbShowImage;
        private System.Windows.Forms.PictureBox btnSelectImage;
        private System.Windows.Forms.Button btnEnd;
        private System.Windows.Forms.Button btnDooDung;
        private System.Windows.Forms.Button btnNew;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label lblShowResultDung;
    }
}