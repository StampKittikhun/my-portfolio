﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyProjectDTI02
{
    public partial class FrmDooDung : Form
    {
        public FrmDooDung()
        {
            InitializeComponent();
            //nameshow มาแสดงที่ label lblnameshow
            lblNameShow.Text = ShareDate.name_show;

            //สั่ง time ให้ Start
            timer1.Start();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void btnMainMenu_Click(object sender, EventArgs e)
        {
            FrmMainMenu frmMainMenu = new FrmMainMenu();
            frmMainMenu.Show();
            this.Hide();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            //show time date realtime
            CultureInfo culture = new CultureInfo("th-TH");
            lblDatetimeShow.Text = DateTime.Now.ToString("วันที่" + "dd เดือน MMMM พ.ศ. yyyy HH:mm:ss" + "  น.", culture);
        }

        private void btnDooDung_Click(object sender, EventArgs e)
        {
            //Validate UI
            if (mtbIDCard.MaskCompleted == false)
            {
                ShareDate.showWarningMSG("ตรวจสอบการป้อน ID CARD");
            }
            else if (tbName.Text.Length == 0)
            {
                ShareDate.showWarningMSG("ตรวจสอบการป้อนชื่อสกุลด้วย");
            }
            else if (dtpBirthDate.Value.Date >= DateTime.Now.Date)
            {
                ShareDate.showWarningMSG("ตรวจสอบวันเดือนปีเกิดด้วย ต้องไม่มากกว่าหรือเท่ากับวันปัจจุบัน");
            }
            else if (nudWeight.Value == 0)
            {
                ShareDate.showWarningMSG("ตรวจสอบการป้อนน้ำหนัก");
            }
            else if (nudHeight.Value == 0)
            {
                ShareDate.showWarningMSG("ตรวจสอบการป้อนน้ำหนักด้วย");
            }
            else
            {
                //เอาข้อมูลที่ป้อนไปแสดง แล้วประมวลผลดวงตามเดือนเกิด
                lblIdCard.Text = mtbIDCard.Text;
                lblName.Text = tbName.Text;
                //วันเดือนปีเกิด
                CultureInfo culture = new CultureInfo("th-TH");
                lblBirthDate.Text = dtpBirthDate.Value.Date.ToString("วันที่ dd เดือน MMMM พ.ศ. yyyy", culture);
                lblAge.Text = (DateTime.Now.Date.Year - dtpBirthDate.Value.Date.Year).ToString();
                lblWeight.Text = nudWeight.Value.ToString("0.00");
                lblHeight.Text = nudHeight.Value.ToString("0.00");
                //ผลดวง โดยเอาเดือนมาตรวจสอบ
                int month = dtpBirthDate.Value.Date.Month;
                switch (month)
                {
                    case 1: lblShowResultDung.Text = "ชะตาช่วงนี้ดีนะจ้ะ......"; break;
                    case 2: lblShowResultDung.Text = "ช่วงนี้เดินทางบ่อยนะจ้ะ...."; break;
                    case 3: lblShowResultDung.Text = "คุณกำลังจะรวยแล้วนะจ้ะ...."; break;
                    case 4: lblShowResultDung.Text = "ช่วงนี้ระวังจะถูกรักนะจ้ะ...."; break;
                    case 5: lblShowResultDung.Text = "ช่วงนี้ระวังเดินตกหลุมรักนะจ้ะ...."; break;
                    case 6: lblShowResultDung.Text = "ช่วงนี้ให้ระวังใคร??...."; break;
                    case 7: lblShowResultDung.Text = "ดวงกำลังจะรุ่ง...."; break;
                    case 8: lblShowResultDung.Text = "ช่วงนี้เดินบ่อยนะเพราะรถเสีย...."; break;
                    case 9: lblShowResultDung.Text = "ช่วงนี้ฝนตกบ่อยเพราะฤดูฝน...."; break;
                    case 10: lblShowResultDung.Text = "ช่วงนี้ดวงของคุณกำลังจะลุก..จากที่นั่ง...."; break;
                    case 11: lblShowResultDung.Text = "ช่วงนี้ดวงของคุณกำลังจะดีนะจ้ะ...."; break;
                    case 12: lblShowResultDung.Text = "ช่วงนี้ดูของคุณจะดีขึ้นถ้า...."; break;
                }
            }
        }

        private void btnNew_Click(object sender, EventArgs e)
        {
            //ทุกอย่างกลับเป็นเหมือนเดิม
            mtbIDCard.Clear();
            tbName.Clear();
            dtpBirthDate.Value = DateTime.Now;
            nudWeight.Value = 0;    
            nudHeight.Value = 0;
            lblIdCard.Text = "xxxxxxxxxx";
            lblName.Text = "xxxxxxxxxx";
            lblBirthDate.Text = "xxxxxxxxxx";
            lblAge.Text = "xxxxxxxxxx";
            lblWeight.Text = "xxxxxxxxxx";
            lblHeight.Text = "xxxxxxxxxx";
            lblShowResultDung.Text = "ผลดวง";
        }
    }
}
