﻿
namespace MyProjectDTI02
{
    partial class FrmSAUShop
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            btMainMenu = new System.Windows.Forms.Button();
            label1 = new System.Windows.Forms.Label();
            label2 = new System.Windows.Forms.Label();
            label3 = new System.Windows.Forms.Label();
            label4 = new System.Windows.Forms.Label();
            btCancel = new System.Windows.Forms.Button();
            btCalculate = new System.Windows.Forms.Button();
            chkPen = new System.Windows.Forms.CheckBox();
            groupBox1 = new System.Windows.Forms.GroupBox();
            label22 = new System.Windows.Forms.Label();
            label21 = new System.Windows.Forms.Label();
            lblTotolPay = new System.Windows.Forms.Label();
            tbPen = new System.Windows.Forms.TextBox();
            label5 = new System.Windows.Forms.Label();
            lblPenPay = new System.Windows.Forms.Label();
            lblPencilPay = new System.Windows.Forms.Label();
            label8 = new System.Windows.Forms.Label();
            tbPencil = new System.Windows.Forms.TextBox();
            chkPencil = new System.Windows.Forms.CheckBox();
            lblRubberPay = new System.Windows.Forms.Label();
            label10 = new System.Windows.Forms.Label();
            tbRubber = new System.Windows.Forms.TextBox();
            chkRubber = new System.Windows.Forms.CheckBox();
            lblRulerPay = new System.Windows.Forms.Label();
            label12 = new System.Windows.Forms.Label();
            tbRuler = new System.Windows.Forms.TextBox();
            chkRuler = new System.Windows.Forms.CheckBox();
            lblBookPay = new System.Windows.Forms.Label();
            label14 = new System.Windows.Forms.Label();
            tbBook = new System.Windows.Forms.TextBox();
            chkBook = new System.Windows.Forms.CheckBox();
            label15 = new System.Windows.Forms.Label();
            label16 = new System.Windows.Forms.Label();
            label17 = new System.Windows.Forms.Label();
            label18 = new System.Windows.Forms.Label();
            label19 = new System.Windows.Forms.Label();
            lblDatetimeShow = new System.Windows.Forms.ToolStrip();
            lblNameShow = new System.Windows.Forms.ToolStripLabel();
            lblDatetimeShow1 = new System.Windows.Forms.ToolStripLabel();
            gg = new System.Windows.Forms.Label();
            cbbSale = new System.Windows.Forms.ComboBox();
            timer1 = new System.Windows.Forms.Timer(components);
            groupBox1.SuspendLayout();
            lblDatetimeShow.SuspendLayout();
            SuspendLayout();
            // 
            // btMainMenu
            // 
            btMainMenu.Image = Properties.Resources.pevious1;
            btMainMenu.Location = new System.Drawing.Point(866, 97);
            btMainMenu.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            btMainMenu.Name = "btMainMenu";
            btMainMenu.Size = new System.Drawing.Size(146, 100);
            btMainMenu.TabIndex = 15;
            btMainMenu.Text = "หน้าจอหลัก";
            btMainMenu.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            btMainMenu.UseVisualStyleBackColor = true;
            btMainMenu.Click += btMainMenu_Click;
            // 
            // label1
            // 
            label1.BackColor = System.Drawing.Color.Yellow;
            label1.Font = new System.Drawing.Font("Segoe UI", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label1.ForeColor = System.Drawing.Color.Blue;
            label1.Location = new System.Drawing.Point(111, 97);
            label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(707, 82);
            label1.TabIndex = 14;
            label1.Text = "SAU Shop";
            label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            label1.UseCompatibleTextRendering = true;
            // 
            // label2
            // 
            label2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label2.Location = new System.Drawing.Point(111, 217);
            label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(204, 65);
            label2.TabIndex = 16;
            label2.Text = "รายการสินค้า";
            label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            label2.Click += label2_Click;
            // 
            // label3
            // 
            label3.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label3.Location = new System.Drawing.Point(354, 217);
            label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            label3.Name = "label3";
            label3.Size = new System.Drawing.Size(204, 65);
            label3.TabIndex = 17;
            label3.Text = "จำนวน";
            label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            label4.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label4.Location = new System.Drawing.Point(614, 217);
            label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            label4.Name = "label4";
            label4.Size = new System.Drawing.Size(204, 65);
            label4.TabIndex = 18;
            label4.Text = "คิดเป็นเงิน";
            label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btCancel
            // 
            btCancel.Image = Properties.Resources.cancel;
            btCancel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            btCancel.Location = new System.Drawing.Point(644, 37);
            btCancel.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            btCancel.Name = "btCancel";
            btCancel.Size = new System.Drawing.Size(146, 85);
            btCancel.TabIndex = 20;
            btCancel.Text = "ยกเลิก";
            btCancel.UseVisualStyleBackColor = true;
            btCancel.Click += btCancel_Click;
            // 
            // btCalculate
            // 
            btCalculate.Image = Properties.Resources.calculator2;
            btCalculate.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            btCalculate.Location = new System.Drawing.Point(490, 37);
            btCalculate.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            btCalculate.Name = "btCalculate";
            btCalculate.Size = new System.Drawing.Size(146, 85);
            btCalculate.TabIndex = 19;
            btCalculate.Text = "คำนวณ";
            btCalculate.UseVisualStyleBackColor = true;
            btCalculate.Click += btCalculate_Click;
            // 
            // chkPen
            // 
            chkPen.AutoSize = true;
            chkPen.Location = new System.Drawing.Point(136, 300);
            chkPen.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            chkPen.Name = "chkPen";
            chkPen.Size = new System.Drawing.Size(168, 29);
            chkPen.TabIndex = 21;
            chkPen.Text = "ปากกา 5 บาท/ด้าม";
            chkPen.UseVisualStyleBackColor = true;
            chkPen.Click += chkPen_Click;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(label22);
            groupBox1.Controls.Add(label21);
            groupBox1.Controls.Add(lblTotolPay);
            groupBox1.Controls.Add(btCancel);
            groupBox1.Controls.Add(btCalculate);
            groupBox1.Location = new System.Drawing.Point(80, 603);
            groupBox1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            groupBox1.Name = "groupBox1";
            groupBox1.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            groupBox1.Size = new System.Drawing.Size(809, 147);
            groupBox1.TabIndex = 22;
            groupBox1.TabStop = false;
            // 
            // label22
            // 
            label22.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label22.Location = new System.Drawing.Point(19, 43);
            label22.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            label22.Name = "label22";
            label22.Size = new System.Drawing.Size(204, 65);
            label22.TabIndex = 48;
            label22.Text = "รวมเป็นเงินทั้งสิ้น";
            label22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label21
            // 
            label21.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label21.Location = new System.Drawing.Point(433, 55);
            label21.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            label21.Name = "label21";
            label21.Size = new System.Drawing.Size(49, 38);
            label21.TabIndex = 47;
            label21.Text = "บาท";
            label21.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblTotolPay
            // 
            lblTotolPay.BackColor = System.Drawing.Color.Yellow;
            lblTotolPay.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            lblTotolPay.ForeColor = System.Drawing.Color.Red;
            lblTotolPay.Location = new System.Drawing.Point(231, 32);
            lblTotolPay.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            lblTotolPay.Name = "lblTotolPay";
            lblTotolPay.Size = new System.Drawing.Size(193, 85);
            lblTotolPay.TabIndex = 47;
            lblTotolPay.Text = "0.00";
            lblTotolPay.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tbPen
            // 
            tbPen.Enabled = false;
            tbPen.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            tbPen.Location = new System.Drawing.Point(359, 298);
            tbPen.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            tbPen.Name = "tbPen";
            tbPen.PlaceholderText = "0";
            tbPen.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            tbPen.Size = new System.Drawing.Size(141, 31);
            tbPen.TabIndex = 23;
            tbPen.KeyPress += tbPen_KeyPress;
            tbPen.KeyUp += tbPen_KeyUp;
            // 
            // label5
            // 
            label5.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label5.Location = new System.Drawing.Point(510, 295);
            label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            label5.Name = "label5";
            label5.Size = new System.Drawing.Size(49, 38);
            label5.TabIndex = 24;
            label5.Text = "ด้าม";
            label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblPenPay
            // 
            lblPenPay.BackColor = System.Drawing.Color.Yellow;
            lblPenPay.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            lblPenPay.ForeColor = System.Drawing.Color.Red;
            lblPenPay.Location = new System.Drawing.Point(614, 300);
            lblPenPay.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            lblPenPay.Name = "lblPenPay";
            lblPenPay.Size = new System.Drawing.Size(143, 38);
            lblPenPay.TabIndex = 25;
            lblPenPay.Text = "0.00";
            lblPenPay.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblPencilPay
            // 
            lblPencilPay.BackColor = System.Drawing.Color.Yellow;
            lblPencilPay.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            lblPencilPay.ForeColor = System.Drawing.Color.Red;
            lblPencilPay.Location = new System.Drawing.Point(614, 348);
            lblPencilPay.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            lblPencilPay.Name = "lblPencilPay";
            lblPencilPay.Size = new System.Drawing.Size(143, 38);
            lblPencilPay.TabIndex = 29;
            lblPencilPay.Text = "0.00";
            lblPencilPay.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label8
            // 
            label8.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label8.Location = new System.Drawing.Point(510, 343);
            label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            label8.Name = "label8";
            label8.Size = new System.Drawing.Size(49, 38);
            label8.TabIndex = 28;
            label8.Text = "ด้าม";
            label8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tbPencil
            // 
            tbPencil.Enabled = false;
            tbPencil.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            tbPencil.Location = new System.Drawing.Point(359, 347);
            tbPencil.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            tbPencil.Name = "tbPencil";
            tbPencil.PlaceholderText = "0";
            tbPencil.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            tbPencil.Size = new System.Drawing.Size(141, 31);
            tbPencil.TabIndex = 27;
            tbPencil.KeyPress += tbPencil_KeyPress;
            tbPencil.KeyUp += tbPencil_KeyUp;
            // 
            // chkPencil
            // 
            chkPencil.AutoSize = true;
            chkPencil.Location = new System.Drawing.Point(136, 348);
            chkPencil.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            chkPencil.Name = "chkPencil";
            chkPencil.Size = new System.Drawing.Size(187, 29);
            chkPencil.TabIndex = 26;
            chkPencil.Text = "ดินสอ 1.50 บาท/ด้าม";
            chkPencil.UseVisualStyleBackColor = true;
            chkPencil.Click += chkPencil_Click;
            // 
            // lblRubberPay
            // 
            lblRubberPay.BackColor = System.Drawing.Color.Yellow;
            lblRubberPay.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            lblRubberPay.ForeColor = System.Drawing.Color.Red;
            lblRubberPay.Location = new System.Drawing.Point(614, 397);
            lblRubberPay.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            lblRubberPay.Name = "lblRubberPay";
            lblRubberPay.Size = new System.Drawing.Size(143, 38);
            lblRubberPay.TabIndex = 33;
            lblRubberPay.Text = "0.00";
            lblRubberPay.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label10
            // 
            label10.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label10.Location = new System.Drawing.Point(510, 392);
            label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            label10.Name = "label10";
            label10.Size = new System.Drawing.Size(49, 38);
            label10.TabIndex = 32;
            label10.Text = "ก้อน";
            label10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tbRubber
            // 
            tbRubber.Enabled = false;
            tbRubber.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            tbRubber.Location = new System.Drawing.Point(359, 395);
            tbRubber.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            tbRubber.Name = "tbRubber";
            tbRubber.PlaceholderText = "0";
            tbRubber.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            tbRubber.Size = new System.Drawing.Size(141, 31);
            tbRubber.TabIndex = 31;
            tbRubber.KeyPress += tbRubber_KeyPress;
            tbRubber.KeyUp += tbRubber_KeyUp;
            // 
            // chkRubber
            // 
            chkRubber.AutoSize = true;
            chkRubber.Location = new System.Drawing.Point(136, 397);
            chkRubber.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            chkRubber.Name = "chkRubber";
            chkRubber.Size = new System.Drawing.Size(193, 29);
            chkRubber.TabIndex = 30;
            chkRubber.Text = "ยางลบ 2.50 บาท/ก้อน";
            chkRubber.UseVisualStyleBackColor = true;
            chkRubber.Click += chkRubber_Click;
            // 
            // lblRulerPay
            // 
            lblRulerPay.BackColor = System.Drawing.Color.Yellow;
            lblRulerPay.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            lblRulerPay.ForeColor = System.Drawing.Color.Red;
            lblRulerPay.Location = new System.Drawing.Point(614, 445);
            lblRulerPay.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            lblRulerPay.Name = "lblRulerPay";
            lblRulerPay.Size = new System.Drawing.Size(143, 38);
            lblRulerPay.TabIndex = 37;
            lblRulerPay.Text = "0.00";
            lblRulerPay.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label12
            // 
            label12.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label12.Location = new System.Drawing.Point(510, 440);
            label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            label12.Name = "label12";
            label12.Size = new System.Drawing.Size(49, 38);
            label12.TabIndex = 36;
            label12.Text = "อัน";
            label12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tbRuler
            // 
            tbRuler.Enabled = false;
            tbRuler.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            tbRuler.Location = new System.Drawing.Point(359, 443);
            tbRuler.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            tbRuler.Name = "tbRuler";
            tbRuler.PlaceholderText = "0";
            tbRuler.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            tbRuler.Size = new System.Drawing.Size(141, 31);
            tbRuler.TabIndex = 35;
            tbRuler.KeyPress += tbRuler_KeyPress;
            tbRuler.KeyUp += tbRuler_KeyUp;
            // 
            // chkRuler
            // 
            chkRuler.AutoSize = true;
            chkRuler.Location = new System.Drawing.Point(136, 445);
            chkRuler.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            chkRuler.Name = "chkRuler";
            chkRuler.Size = new System.Drawing.Size(179, 29);
            chkRuler.TabIndex = 34;
            chkRuler.Text = "ไม้บรรทัด 2 บาท/อัน";
            chkRuler.UseVisualStyleBackColor = true;
            chkRuler.Click += chkRuler_Click;
            // 
            // lblBookPay
            // 
            lblBookPay.BackColor = System.Drawing.Color.Yellow;
            lblBookPay.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            lblBookPay.ForeColor = System.Drawing.Color.Red;
            lblBookPay.Location = new System.Drawing.Point(614, 493);
            lblBookPay.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            lblBookPay.Name = "lblBookPay";
            lblBookPay.Size = new System.Drawing.Size(143, 38);
            lblBookPay.TabIndex = 41;
            lblBookPay.Text = "0.00";
            lblBookPay.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label14
            // 
            label14.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label14.Location = new System.Drawing.Point(510, 488);
            label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            label14.Name = "label14";
            label14.Size = new System.Drawing.Size(49, 38);
            label14.TabIndex = 40;
            label14.Text = "เล่ม";
            label14.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tbBook
            // 
            tbBook.Enabled = false;
            tbBook.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            tbBook.Location = new System.Drawing.Point(359, 492);
            tbBook.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            tbBook.Name = "tbBook";
            tbBook.PlaceholderText = "0";
            tbBook.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            tbBook.Size = new System.Drawing.Size(141, 31);
            tbBook.TabIndex = 39;
            tbBook.KeyPress += tbBook_KeyPress;
            tbBook.KeyUp += tbBook_KeyUp;
            // 
            // chkBook
            // 
            chkBook.AutoSize = true;
            chkBook.Location = new System.Drawing.Point(136, 493);
            chkBook.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            chkBook.Name = "chkBook";
            chkBook.Size = new System.Drawing.Size(183, 29);
            chkBook.TabIndex = 38;
            chkBook.Text = "สมุด 10.20 บาท/เล่ม";
            chkBook.UseVisualStyleBackColor = true;
            chkBook.Click += chkBook_Click;
            // 
            // label15
            // 
            label15.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label15.Location = new System.Drawing.Point(777, 300);
            label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            label15.Name = "label15";
            label15.Size = new System.Drawing.Size(49, 38);
            label15.TabIndex = 42;
            label15.Text = "บาท";
            label15.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label16
            // 
            label16.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label16.Location = new System.Drawing.Point(777, 348);
            label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            label16.Name = "label16";
            label16.Size = new System.Drawing.Size(49, 38);
            label16.TabIndex = 43;
            label16.Text = "บาท";
            label16.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label17
            // 
            label17.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label17.Location = new System.Drawing.Point(777, 397);
            label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            label17.Name = "label17";
            label17.Size = new System.Drawing.Size(49, 38);
            label17.TabIndex = 44;
            label17.Text = "บาท";
            label17.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label18
            // 
            label18.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label18.Location = new System.Drawing.Point(777, 445);
            label18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            label18.Name = "label18";
            label18.Size = new System.Drawing.Size(49, 38);
            label18.TabIndex = 45;
            label18.Text = "บาท";
            label18.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label19
            // 
            label19.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label19.Location = new System.Drawing.Point(777, 487);
            label19.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            label19.Name = "label19";
            label19.Size = new System.Drawing.Size(49, 38);
            label19.TabIndex = 46;
            label19.Text = "บาท";
            label19.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblDatetimeShow
            // 
            lblDatetimeShow.Dock = System.Windows.Forms.DockStyle.Bottom;
            lblDatetimeShow.ImageScalingSize = new System.Drawing.Size(24, 24);
            lblDatetimeShow.Items.AddRange(new System.Windows.Forms.ToolStripItem[] { lblNameShow, lblDatetimeShow1 });
            lblDatetimeShow.Location = new System.Drawing.Point(0, 787);
            lblDatetimeShow.Name = "lblDatetimeShow";
            lblDatetimeShow.Padding = new System.Windows.Forms.Padding(0, 0, 3, 0);
            lblDatetimeShow.Size = new System.Drawing.Size(1143, 30);
            lblDatetimeShow.TabIndex = 47;
            lblDatetimeShow.Text = "toolStrip1";
            // 
            // lblNameShow
            // 
            lblNameShow.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            lblNameShow.ForeColor = System.Drawing.Color.Blue;
            lblNameShow.Name = "lblNameShow";
            lblNameShow.Size = new System.Drawing.Size(70, 25);
            lblNameShow.Text = "Name?";
            // 
            // lblDatetimeShow1
            // 
            lblDatetimeShow1.Name = "lblDatetimeShow1";
            lblDatetimeShow1.Size = new System.Drawing.Size(90, 25);
            lblDatetimeShow1.Text = "datetime?";
            // 
            // gg
            // 
            gg.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            gg.Location = new System.Drawing.Point(179, 540);
            gg.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            gg.Name = "gg";
            gg.Size = new System.Drawing.Size(137, 65);
            gg.TabIndex = 48;
            gg.Text = "ส่วนลด";
            gg.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // cbbSale
            // 
            cbbSale.FormattingEnabled = true;
            cbbSale.Items.AddRange(new object[] { "ไม่มีส่วนลด", "นักศึกษาลด 10 %", "เจ้านักที่ลด 7 %", "อาจารย์ลด 5 %" });
            cbbSale.Location = new System.Drawing.Point(359, 558);
            cbbSale.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            cbbSale.Name = "cbbSale";
            cbbSale.Size = new System.Drawing.Size(140, 33);
            cbbSale.TabIndex = 49;
            cbbSale.KeyPress += cbbSale_KeyPress;
            // 
            // timer1
            // 
            timer1.Tick += timer1_Tick;
            // 
            // FrmSAUShop
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            ClientSize = new System.Drawing.Size(1143, 817);
            Controls.Add(cbbSale);
            Controls.Add(gg);
            Controls.Add(lblDatetimeShow);
            Controls.Add(label19);
            Controls.Add(label18);
            Controls.Add(label17);
            Controls.Add(label16);
            Controls.Add(label15);
            Controls.Add(lblBookPay);
            Controls.Add(label14);
            Controls.Add(tbBook);
            Controls.Add(chkBook);
            Controls.Add(lblRulerPay);
            Controls.Add(label12);
            Controls.Add(tbRuler);
            Controls.Add(chkRuler);
            Controls.Add(lblRubberPay);
            Controls.Add(label10);
            Controls.Add(tbRubber);
            Controls.Add(chkRubber);
            Controls.Add(lblPencilPay);
            Controls.Add(label8);
            Controls.Add(tbPencil);
            Controls.Add(chkPencil);
            Controls.Add(lblPenPay);
            Controls.Add(label5);
            Controls.Add(tbPen);
            Controls.Add(groupBox1);
            Controls.Add(chkPen);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(btMainMenu);
            Controls.Add(label1);
            ForeColor = System.Drawing.Color.Black;
            Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            Name = "FrmSAUShop";
            Text = "FrmSAUShop";
            Load += FrmSAUShop_Load;
            groupBox1.ResumeLayout(false);
            lblDatetimeShow.ResumeLayout(false);
            lblDatetimeShow.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Button btMainMenu;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btCancel;
        private System.Windows.Forms.Button btCalculate;
        private System.Windows.Forms.CheckBox chkPen;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label lblTotolPay;
        private System.Windows.Forms.TextBox tbPen;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lblPenPay;
        private System.Windows.Forms.Label lblPencilPay;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox tbPencil;
        private System.Windows.Forms.CheckBox chkPencil;
        private System.Windows.Forms.Label lblRubberPay;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox tbRubber;
        private System.Windows.Forms.CheckBox chkRubber;
        private System.Windows.Forms.Label lblRulerPay;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox tbRuler;
        private System.Windows.Forms.CheckBox chkRuler;
        private System.Windows.Forms.Label lblBookPay;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox tbBook;
        private System.Windows.Forms.CheckBox chkBook;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.ToolStrip lblDatetimeShow;
        private System.Windows.Forms.ToolStripLabel lblNameShow;
        private System.Windows.Forms.ToolStripLabel lblDatetimeShow1;
        private System.Windows.Forms.Label gg;
        private System.Windows.Forms.ComboBox cbbSale;
        private System.Windows.Forms.Timer timer1;
    }
}