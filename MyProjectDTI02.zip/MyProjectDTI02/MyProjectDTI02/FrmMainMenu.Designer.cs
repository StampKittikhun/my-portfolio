﻿
namespace MyProjectDTI02
{
    partial class FrmMainMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            toolStrip1 = new System.Windows.Forms.ToolStrip();
            lblNameShow = new System.Windows.Forms.ToolStripLabel();
            blDatetimeShow = new System.Windows.Forms.ToolStripLabel();
            label1 = new System.Windows.Forms.Label();
            btWelcome = new System.Windows.Forms.Button();
            btCalculator = new System.Windows.Forms.Button();
            btSAUShop = new System.Windows.Forms.Button();
            btLotto = new System.Windows.Forms.Button();
            btExitApp = new System.Windows.Forms.Button();
            btRegister = new System.Windows.Forms.Button();
            btShape = new System.Windows.Forms.Button();
            btDooDung = new System.Windows.Forms.Button();
            timer1 = new System.Windows.Forms.Timer(components);
            toolStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // toolStrip1
            // 
            toolStrip1.Dock = System.Windows.Forms.DockStyle.Bottom;
            toolStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] { lblNameShow, blDatetimeShow });
            toolStrip1.Location = new System.Drawing.Point(0, 718);
            toolStrip1.Name = "toolStrip1";
            toolStrip1.Padding = new System.Windows.Forms.Padding(0, 0, 3, 0);
            toolStrip1.Size = new System.Drawing.Size(954, 30);
            toolStrip1.TabIndex = 0;
            toolStrip1.Text = "toolStrip1";
            // 
            // lblNameShow
            // 
            lblNameShow.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            lblNameShow.ForeColor = System.Drawing.Color.Blue;
            lblNameShow.Name = "lblNameShow";
            lblNameShow.Size = new System.Drawing.Size(70, 25);
            lblNameShow.Text = "Name?";
            // 
            // blDatetimeShow
            // 
            blDatetimeShow.Name = "blDatetimeShow";
            blDatetimeShow.Size = new System.Drawing.Size(90, 25);
            blDatetimeShow.Text = "datetime?";
            // 
            // label1
            // 
            label1.BackColor = System.Drawing.Color.Yellow;
            label1.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label1.ForeColor = System.Drawing.Color.Blue;
            label1.Location = new System.Drawing.Point(54, 45);
            label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(814, 100);
            label1.TabIndex = 2;
            label1.Text = "DTI Soft V.1.0";
            label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btWelcome
            // 
            btWelcome.Image = Properties.Resources.menu11;
            btWelcome.Location = new System.Drawing.Point(54, 177);
            btWelcome.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            btWelcome.Name = "btWelcome";
            btWelcome.Size = new System.Drawing.Size(217, 248);
            btWelcome.TabIndex = 3;
            btWelcome.Text = "Go to Welcome";
            btWelcome.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            btWelcome.UseVisualStyleBackColor = true;
            btWelcome.Click += btWelcome_Click;
            // 
            // btCalculator
            // 
            btCalculator.Image = Properties.Resources.menu2;
            btCalculator.Location = new System.Drawing.Point(280, 177);
            btCalculator.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            btCalculator.Name = "btCalculator";
            btCalculator.Size = new System.Drawing.Size(187, 248);
            btCalculator.TabIndex = 4;
            btCalculator.Text = "Go to Calculator";
            btCalculator.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            btCalculator.UseVisualStyleBackColor = true;
            btCalculator.Click += btCalculator_Click;
            // 
            // btSAUShop
            // 
            btSAUShop.Image = Properties.Resources.menu3;
            btSAUShop.Location = new System.Drawing.Point(476, 177);
            btSAUShop.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            btSAUShop.Name = "btSAUShop";
            btSAUShop.Size = new System.Drawing.Size(186, 248);
            btSAUShop.TabIndex = 5;
            btSAUShop.Text = "Go to SAUShop";
            btSAUShop.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            btSAUShop.UseVisualStyleBackColor = true;
            btSAUShop.Click += btSAUShop_Click;
            // 
            // btLotto
            // 
            btLotto.Image = Properties.Resources.menu4;
            btLotto.Location = new System.Drawing.Point(670, 177);
            btLotto.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            btLotto.Name = "btLotto";
            btLotto.Size = new System.Drawing.Size(199, 248);
            btLotto.TabIndex = 6;
            btLotto.Text = "Go to Lotto";
            btLotto.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            btLotto.UseVisualStyleBackColor = true;
            btLotto.Click += btLotto_Click;
            // 
            // btExitApp
            // 
            btExitApp.Image = Properties.Resources.exitapp;
            btExitApp.Location = new System.Drawing.Point(670, 435);
            btExitApp.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            btExitApp.Name = "btExitApp";
            btExitApp.Size = new System.Drawing.Size(199, 242);
            btExitApp.TabIndex = 10;
            btExitApp.Text = "ออกจากระบบ";
            btExitApp.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            btExitApp.UseVisualStyleBackColor = true;
            btExitApp.Click += btExitApp_Click;
            // 
            // btRegister
            // 
            btRegister.Image = Properties.Resources.menu6;
            btRegister.Location = new System.Drawing.Point(476, 435);
            btRegister.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            btRegister.Name = "btRegister";
            btRegister.Size = new System.Drawing.Size(186, 242);
            btRegister.TabIndex = 9;
            btRegister.Text = "Go to Regiter";
            btRegister.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            btRegister.UseVisualStyleBackColor = true;
            btRegister.Click += btRegister_Click;
            // 
            // btShape
            // 
            btShape.Image = Properties.Resources.menu7;
            btShape.Location = new System.Drawing.Point(280, 435);
            btShape.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            btShape.Name = "btShape";
            btShape.Size = new System.Drawing.Size(187, 242);
            btShape.TabIndex = 8;
            btShape.Text = "Go to ShapeArea";
            btShape.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            btShape.UseVisualStyleBackColor = true;
            btShape.Click += btShape_Click;
            // 
            // btDooDung
            // 
            btDooDung.Image = Properties.Resources.menu5;
            btDooDung.Location = new System.Drawing.Point(54, 435);
            btDooDung.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            btDooDung.Name = "btDooDung";
            btDooDung.Size = new System.Drawing.Size(217, 242);
            btDooDung.TabIndex = 7;
            btDooDung.Text = "Go to DooDung";
            btDooDung.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            btDooDung.UseVisualStyleBackColor = true;
            btDooDung.Click += btDooDung_Click;
            // 
            // timer1
            // 
            timer1.Tick += timer1_Tick;
            // 
            // FrmMainMenu
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            BackColor = System.Drawing.SystemColors.ActiveBorder;
            ClientSize = new System.Drawing.Size(954, 748);
            Controls.Add(btExitApp);
            Controls.Add(btRegister);
            Controls.Add(btShape);
            Controls.Add(btDooDung);
            Controls.Add(btLotto);
            Controls.Add(btSAUShop);
            Controls.Add(btCalculator);
            Controls.Add(btWelcome);
            Controls.Add(label1);
            Controls.Add(toolStrip1);
            Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            Name = "FrmMainMenu";
            Text = "หน้าจอหลัก - DTI Sotf V.1.0";
            toolStrip1.ResumeLayout(false);
            toolStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripLabel lblNameShow;
        private System.Windows.Forms.ToolStripLabel blDatetimeShow;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btWelcome;
        private System.Windows.Forms.Button btCalculator;
        private System.Windows.Forms.Button btSAUShop;
        private System.Windows.Forms.Button btLotto;
        private System.Windows.Forms.Button btExitApp;
        private System.Windows.Forms.Button btRegister;
        private System.Windows.Forms.Button btShape;
        private System.Windows.Forms.Button btDooDung;
        private System.Windows.Forms.Timer timer1;
    }
}