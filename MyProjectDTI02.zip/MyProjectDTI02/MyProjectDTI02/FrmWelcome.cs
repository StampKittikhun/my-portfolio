﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyProjectDTI02
{
    public partial class FrmWelcome : Form
    {
        public FrmWelcome()
        {
            InitializeComponent();
            //nameshow มาแสดงที่ label lblnameshow
            lblNameShow.Text = ShareDate.name_show;

            //สั่ง time ให้ Start
            timer1.Start();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void tbUsername_TextChanged(object sender, EventArgs e)
        {

        }

        private void btMainMenu_Click(object sender, EventArgs e)
        {
            FrmMainMenu frmMainMenu = new FrmMainMenu();
            frmMainMenu.Show();
            this.Hide();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            //show time date realtime
            CultureInfo culture = new CultureInfo("th-TH");
            lblDatetimeShow.Text = DateTime.Now.ToString("วันที่" + "dd เดือน MMMM พ.ศ. yyyy HH:mm:ss" + "  น.", culture);
        }

        private void tbName_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar)&& !char.IsControl(e.KeyChar)&& char.IsWhiteSpace(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void btOk_Click(object sender, EventArgs e)
        {
            //validate 
            if(tbName.Text.Length == 0)
            {
                MessageBox.Show(
                    "ป้อน Name ด้วย", 
                    "คำเตือน", 
                    MessageBoxButtons.OK, 
                    MessageBoxIcon.Warning
                    );
            }
            else if (dtpBirthDate.Value.Date >=DateTime.Now.Date)
            {
                MessageBox.Show(
                 "ว/ด/ป เกิดต้องน้อยกว่าปัจจุบัน",
                 "คำเตือน",
                 MessageBoxButtons.OK,
                 MessageBoxIcon.Warning
                 );
            }
            else
            {
                //เอาข้อมูลที่เลือกมาแสดง
                //โดยนำข้อมูลทั้งหมด มาเฃื่อมต่อกัน
                string dataShow = "";
                dataShow = dataShow + "ชื่อ:" + tbName.Text +"\n";

                CultureInfo culture = new CultureInfo("th-TH");
                dataShow = dataShow +"วันเกิด: " + dtpBirthDate.Value.Date.ToString("dd เดือน MMMM พ.ศ. yyyy",culture) + "\n";

                int age = DateTime.Now.Year - dtpBirthDate.Value.Date.Year;
                dataShow = dataShow + "อายุ:" + age + "\n";

                if (rdoMale.Checked == true)
                {
                    dataShow = dataShow + "เพศ : ชาย";

                }
                else
                {
                    dataShow = dataShow + "เพส : หญิง";
                }
                lblShowResult.Text = dataShow;
            }
        }

        private void btCancel_Click(object sender, EventArgs e)
        {
            tbName.Clear();
            dtpBirthDate.Value = DateTime.Now;
            rdoMale.Checked = true;
            lblShowResult.Text = "?????";
        }
    }
}
